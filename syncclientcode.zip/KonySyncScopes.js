if(typeof(com)=== "undefined"){ com = {}; }
if(typeof(com.kony)=== "undefined"){ com.kony = {}; }
if(typeof(com.kony.WeightWatchers)=== "undefined"){ com.kony.WeightWatchers = {}; }
if(typeof(com.kony.WeightWatchers.ProductSyncScope)=== "undefined"){ com.kony.WeightWatchers.ProductSyncScope = {}; }
if(typeof(com.kony.WeightWatchers.ProductSyncScope.ProductSyncScope)=== "undefined"){ com.kony.WeightWatchers.ProductSyncScope.ProductSyncScope = {}; }

//API call will trigger ProductSyncScope reset
com.kony.WeightWatchers.ProductSyncScope.ProductSyncScope.reset = function(successcallback,errorcallback){
	if(!kony.sync.isSyncInitialized(errorcallback)){
		return;
	}
	kony.sync.scopeReset("ProductSyncScope",successcallback,errorcallback);
}



if(typeof(com)=== "undefined"){ com = {}; }
if(typeof(com.kony)=== "undefined"){ com.kony = {}; }
if(typeof(com.kony.WeightWatchers)=== "undefined"){ com.kony.WeightWatchers = {}; }
if(typeof(com.kony.WeightWatchers.MeetingUpload)=== "undefined"){ com.kony.WeightWatchers.MeetingUpload = {}; }
if(typeof(com.kony.WeightWatchers.MeetingUpload.MeetingUpload)=== "undefined"){ com.kony.WeightWatchers.MeetingUpload.MeetingUpload = {}; }

//API call will trigger MeetingUpload reset
com.kony.WeightWatchers.MeetingUpload.MeetingUpload.reset = function(successcallback,errorcallback){
	if(!kony.sync.isSyncInitialized(errorcallback)){
		return;
	}
	kony.sync.scopeReset("MeetingUpload",successcallback,errorcallback);
}



if(typeof(com)=== "undefined"){ com = {}; }
if(typeof(com.kony)=== "undefined"){ com.kony = {}; }
if(typeof(com.kony.WeightWatchers)=== "undefined"){ com.kony.WeightWatchers = {}; }
if(typeof(com.kony.WeightWatchers.MemberSyncScope)=== "undefined"){ com.kony.WeightWatchers.MemberSyncScope = {}; }
if(typeof(com.kony.WeightWatchers.MemberSyncScope.MemberSyncScope)=== "undefined"){ com.kony.WeightWatchers.MemberSyncScope.MemberSyncScope = {}; }

//API call will trigger MemberSyncScope reset
com.kony.WeightWatchers.MemberSyncScope.MemberSyncScope.reset = function(successcallback,errorcallback){
	if(!kony.sync.isSyncInitialized(errorcallback)){
		return;
	}
	kony.sync.scopeReset("MemberSyncScope",successcallback,errorcallback);
}



if(typeof(com)=== "undefined"){ com = {}; }
if(typeof(com.kony)=== "undefined"){ com.kony = {}; }
if(typeof(com.kony.WeightWatchers)=== "undefined"){ com.kony.WeightWatchers = {}; }
if(typeof(com.kony.WeightWatchers.LookUpTables)=== "undefined"){ com.kony.WeightWatchers.LookUpTables = {}; }
if(typeof(com.kony.WeightWatchers.LookUpTables.LookUpTables)=== "undefined"){ com.kony.WeightWatchers.LookUpTables.LookUpTables = {}; }

//API call will trigger LookUpTables reset
com.kony.WeightWatchers.LookUpTables.LookUpTables.reset = function(successcallback,errorcallback){
	if(!kony.sync.isSyncInitialized(errorcallback)){
		return;
	}
	kony.sync.scopeReset("LookUpTables",successcallback,errorcallback);
}



if(typeof(com)=== "undefined"){ com = {}; }
if(typeof(com.kony)=== "undefined"){ com.kony = {}; }
if(typeof(com.kony.WeightWatchers)=== "undefined"){ com.kony.WeightWatchers = {}; }
if(typeof(com.kony.WeightWatchers.Logger)=== "undefined"){ com.kony.WeightWatchers.Logger = {}; }
if(typeof(com.kony.WeightWatchers.Logger.Logger)=== "undefined"){ com.kony.WeightWatchers.Logger.Logger = {}; }

//API call will trigger Logger reset
com.kony.WeightWatchers.Logger.Logger.reset = function(successcallback,errorcallback){
	if(!kony.sync.isSyncInitialized(errorcallback)){
		return;
	}
	kony.sync.scopeReset("Logger",successcallback,errorcallback);
}



if(typeof(com)=== "undefined"){ com = {}; }
if(typeof(com.kony)=== "undefined"){ com.kony = {}; }
if(typeof(com.kony.WeightWatchers)=== "undefined"){ com.kony.WeightWatchers = {}; }
if(typeof(com.kony.WeightWatchers.MeetingSyncScope)=== "undefined"){ com.kony.WeightWatchers.MeetingSyncScope = {}; }
if(typeof(com.kony.WeightWatchers.MeetingSyncScope.MeetingSyncScope)=== "undefined"){ com.kony.WeightWatchers.MeetingSyncScope.MeetingSyncScope = {}; }

//API call will trigger MeetingSyncScope reset
com.kony.WeightWatchers.MeetingSyncScope.MeetingSyncScope.reset = function(successcallback,errorcallback){
	if(!kony.sync.isSyncInitialized(errorcallback)){
		return;
	}
	kony.sync.scopeReset("MeetingSyncScope",successcallback,errorcallback);
}



if(typeof(com)=== "undefined"){ com = {}; }
if(typeof(com.kony)=== "undefined"){ com.kony = {}; }
if(typeof(com.kony.WeightWatchers)=== "undefined"){ com.kony.WeightWatchers = {}; }
if(typeof(com.kony.WeightWatchers.Tally)=== "undefined"){ com.kony.WeightWatchers.Tally = {}; }
if(typeof(com.kony.WeightWatchers.Tally.Tally)=== "undefined"){ com.kony.WeightWatchers.Tally.Tally = {}; }

//API call will trigger Tally reset
com.kony.WeightWatchers.Tally.Tally.reset = function(successcallback,errorcallback){
	if(!kony.sync.isSyncInitialized(errorcallback)){
		return;
	}
	kony.sync.scopeReset("Tally",successcallback,errorcallback);
}



if(typeof(com)=== "undefined"){ com = {}; }
if(typeof(com.kony)=== "undefined"){ com.kony = {}; }
if(typeof(com.kony.WeightWatchers)=== "undefined"){ com.kony.WeightWatchers = {}; }
if(typeof(com.kony.WeightWatchers.TallySyncScope)=== "undefined"){ com.kony.WeightWatchers.TallySyncScope = {}; }
if(typeof(com.kony.WeightWatchers.TallySyncScope.TallySyncScope)=== "undefined"){ com.kony.WeightWatchers.TallySyncScope.TallySyncScope = {}; }

//API call will trigger TallySyncScope reset
com.kony.WeightWatchers.TallySyncScope.TallySyncScope.reset = function(successcallback,errorcallback){
	if(!kony.sync.isSyncInitialized(errorcallback)){
		return;
	}
	kony.sync.scopeReset("TallySyncScope",successcallback,errorcallback);
}




// **********************************Start Scope definition************************
konysyncClientSyncConfig ={
     "AppID": "10000169166677bc1",
     "Version": "17b7d571221ff48814a3a4e471d49648a8a09dc42006b17d0dec273dc1ef718b",
     "ArrayOfSyncScope": [
          {
               "ScopeName": "ProductSyncScope",
               "ScopeTables": [
                    {
                         "Relationships": {"OneToMany": [{
                              "RelationshipAttributes": [{
                                   "SourceObject_Attribute": "ProductID",
                                   "TargetObject_Attribute": "ProductID"
                              }],
                              "TargetObject": "OfferDetail",
                              "Cascade": "true"
                         }]},
                         "Pk_Columns": [
                              "ProductID",
                              "LocationID"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "sku"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "UnitPrice"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "description"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ProductID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Category"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "CategoryNo"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsActive"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsMonthlyPass"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsNewEnrollment"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsSeventeenWkPs"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsSeventeenWPEn"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsTaxIncluded"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LocationID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PosProductType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "UnitPriceTax"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Type"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsFeaturedProduct"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ProductCategoryDesc"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "UPC"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "TaxRate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "IsPrepaymentPlan"
                              }
                         ],
                         "Name": "ProductDetail"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": [
                              "OfferDesc",
                              "ProductID",
                              "LocationId"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "AutoApplied"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "DiscountValue"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "OfferDesc",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ProductID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "OfferNo"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LocationId",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "DiscountedProductPrice"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "OfferUnitPriceTax"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "StartDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "EndDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "OfferID"
                              }
                         ],
                         "Name": "OfferDetail"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["Id"],
                         "Columns": [
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Action"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "AgeGreaterThan"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsDefault"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MissedWeekMax"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MissedWeekMin"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SKU"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Subscription"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Transact"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "WeightDiff"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "LocationId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "LocationNum"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "isPrepaid"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "PriceOverride"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PriceOverideSKU"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "RegistrationStatus"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LineOfBusiness"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "SeriesLength"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "WeeksLeft"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "IsExtended"
                              }
                         ],
                         "Name": "SKURuleEngine"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": [
                              "MilestoneID",
                              "CountryID"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MilestoneID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MilestoneTypeID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MilestoneName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MilestonTypName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MilestoneDesc"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID",
                                   "IsPrimaryKey": true
                              }
                         ],
                         "Name": "MilestoneLookUp"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": [
                              "MeetingTypeID",
                              "CountryID"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MeetingTypeName"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MeetingTypeID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Length"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID",
                                   "IsPrimaryKey": true
                              }
                         ],
                         "Name": "MeetingTypes"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": [
                              "StateID",
                              "CountryID"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "StateName"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "StateID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "StateCode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "StateABBR"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID",
                                   "IsPrimaryKey": true
                              }
                         ],
                         "Name": "StatesLookup"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": [
                              "CountryID",
                              "TallyDiffReasonId"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "TallyDiffReasonId",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "TallyDiffReasonDesc"
                              }
                         ],
                         "Name": "TallyDiffReasonLookup"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": [
                              "CountryID",
                              "PaymentTypeId"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PaymentTypeDesc"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PaymentTypeId",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PaymentDisplayName"
                              }
                         ],
                         "Name": "PaymentTypeLookup"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": [
                              "CountryID",
                              "Id"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Desc"
                              }
                         ],
                         "Name": "PriceOverrideReasonsLookup"
                    }
               ],
               "Strategy": "OTA_SYNC",
               "ScopeDatabaseName": "10000169166677bc1",
               "DataSource": "7693efa9-08de-430d-a233-88481a1b13bd"
          },
          {
               "ScopeName": "MeetingUpload",
               "ScopeTables": [{
                    "Relationships": {},
                    "Pk_Columns": ["meetingid"],
                    "Columns": [
                         {
                              "IsNullable": false,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "ID"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "date",
                              "Name": "MeetingDate"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "TransactionType"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "date",
                              "Name": "Date"
                         },
                         {
                              "IsNullable": false,
                              "Autogenerated": "true",
                              "type": "string",
                              "Name": "meetingid",
                              "IsPrimaryKey": true
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "Locale"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "CountryID"
                         }
                    ],
                    "Name": "MeetingsUpdate"
               }],
               "Strategy": "OTA_SYNC",
               "ScopeDatabaseName": "10000169166677bc1",
               "DataSource": "7693efa9-08de-430d-a233-88481a1b13bd"
          },
          {
               "ScopeName": "MemberSyncScope",
               "ScopeTables": [
                    {
                         "Relationships": {"OneToMany": [
                              {
                                   "RelationshipAttributes": [{
                                        "SourceObject_Attribute": "MemberID",
                                        "TargetObject_Attribute": "MemberID"
                                   }],
                                   "TargetObject": "WeighDetails",
                                   "Cascade": "false"
                              },
                              {
                                   "RelationshipAttributes": [{
                                        "SourceObject_Attribute": "MemberID",
                                        "TargetObject_Attribute": "MemberID"
                                   }],
                                   "TargetObject": "MilestoneAchieved",
                                   "Cascade": "false"
                              },
                              {
                                   "RelationshipAttributes": [{
                                        "SourceObject_Attribute": "MemberID",
                                        "TargetObject_Attribute": "MemberID"
                                   }],
                                   "TargetObject": "MilestoneEligible",
                                   "Cascade": "false"
                              },
                              {
                                   "RelationshipAttributes": [{
                                        "SourceObject_Attribute": "MemberID",
                                        "TargetObject_Attribute": "MemberID"
                                   }],
                                   "TargetObject": "NoteDetails",
                                   "Cascade": "false"
                              },
                              {
                                   "RelationshipAttributes": [{
                                        "SourceObject_Attribute": "MemberID",
                                        "TargetObject_Attribute": "MemberID"
                                   }],
                                   "TargetObject": "RefferalDetails",
                                   "Cascade": "false"
                              },
                              {
                                   "RelationshipAttributes": [{
                                        "SourceObject_Attribute": "MemberID",
                                        "TargetObject_Attribute": "MemberID"
                                   }],
                                   "TargetObject": "SaleDetails",
                                   "Cascade": "false"
                              },
                              {
                                   "RelationshipAttributes": [{
                                        "SourceObject_Attribute": "MemberID",
                                        "TargetObject_Attribute": "MemberID"
                                   }],
                                   "TargetObject": "PreActivation",
                                   "Cascade": "false"
                              }
                         ]},
                         "InputOperations": {
                              "insert": {"isRoot": ["true"]},
                              "update": {"isRoot": ["true"]},
                              "getupdated": {"isRoot": ["true"]}
                         },
                         "Pk_Columns": [
                              "MemberID",
                              "PreRegNumber"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "DontContByEmail"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "DateOfBirth"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Email"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "EmpID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "FirstName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Gender"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Height"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "LastName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "SubscriptnID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SubscriptnType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "RegNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "LastUpdatedTime"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "BillingAddr1"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "BillingAddr2"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "BillingCity"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "BillingCountry"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "BillingState"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "BillingZipCode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ConsWeightGain"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "CrntLifeTimeSta"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "DontRecvCalls"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "DontCnctPhone"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "DontCnctSMS"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "DontSendCard"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "DontSendCoupon"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "EnrollmentDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "FeePaid"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LastAchvdMStone"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "LastContactDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "LastNteEntrDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LocationID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "MeetingDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MtngOccrID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CouponCode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "ExpirationDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "LastUsedDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ProductID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MissWeekPasses"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "NoWeeksAttended"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Phone1"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PhoneType1"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Phone2"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PhoneType2"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "PrevLifeTimeSta"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ShippingAddr1"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ShippingAddr2"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ShippingCity"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ShippingCountry"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ShippingState"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ShippingZipCode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "StartDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberStatus"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "TransactionType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "WeeksCompleted"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "WeightGain"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MeetingId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "long",
                                   "Name": "MemTypeUpdateDt"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "RegStatus"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "string",
                                   "Name": "MemberID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "GoalWeight"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "GoalAchDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "StartWeight"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "RegDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IncompleteData"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "PreRegNumber",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "UniqueID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "UserStsEndPrd"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "UserComments"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "UserStsChngRsn"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "IsPAYG"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsMemberInMtns"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "EmailID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "EnterpriseID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "LinkType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "UserName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsFreshStart"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "RefreshDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "SessionNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "TrackerID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "MaintenanceMode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "TrackerStartDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "FailedDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "Eligible"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "EligibleDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "PaidLastFee"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "WeightCountMet"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ReedeemedPasses"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "RedeemedDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "IsDateRedeemed"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "IsLink"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsCurrentWeekWeighed"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "LastAttendanceDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberRole"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ProgramDuration"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "isVoided"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "PersonalGoalWeight"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "PersonalGoalWeightDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "SubscriptnDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Usertype"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PlanType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CommitmentDuration"
                              }
                         ],
                         "Name": "MemberDetails"
                    },
                    {
                         "Relationships": {"OneToMany": [{
                              "RelationshipAttributes": [
                                   {
                                        "SourceObject_Attribute": "MemberID",
                                        "TargetObject_Attribute": "MemberID"
                                   },
                                   {
                                        "SourceObject_Attribute": "WeekNumber",
                                        "TargetObject_Attribute": "WeekNumber"
                                   }
                              ],
                              "TargetObject": "MilestoneAchieved",
                              "Cascade": "true"
                         }]},
                         "InputOperations": {
                              "insert": {"isRoot": ["true"]},
                              "update": {"isRoot": ["true"]},
                              "getupdated": {"isRoot": ["true"]}
                         },
                         "Pk_Columns": [
                              "WeekNumber",
                              "MemberID"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "DailyPtTarget"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "EmpID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsAtndgMeeting"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "NoWeighIn"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "ManualWeighIn"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "MeetingDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MtngOccrID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MilestoneID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ReachedDate"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "WeekNumber",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "WeighInDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "Weight"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "WeighId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "WeighMSDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "Height"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LocationID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "SessionNumber"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "WeightLoss"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "modifiedLast"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "IsMemberAtRisk"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "WeeklyPointsAllowance"
                              }
                         ],
                         "Name": "WeighDetails"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {
                              "insert": {"isRoot": ["true"]},
                              "getupdated": {"isRoot": ["true"]}
                         },
                         "Pk_Columns": [
                              "MemberID",
                              "MemberMilestoneID",
                              "ID"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MilestoneID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "ReachedDate"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "WeighInDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "LocationNum"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "WeekNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MilestoneName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MeetingID"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "string",
                                   "Name": "MemberMilestoneID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "ID",
                                   "IsPrimaryKey": true
                              }
                         ],
                         "Name": "MilestoneAchieved"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {"getupdated": {"isRoot": ["true"]}},
                         "Pk_Columns": [
                              "MilestoneID",
                              "MemberID"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MilestoneID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "TargetWeight"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsAchieved"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "LocationNum"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "ReachedDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "WeekNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "WeighInDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              }
                         ],
                         "Name": "MilestoneEligible"
                    },
                    {
                         "Relationships": {"OneToMany": [
                              {
                                   "RelationshipAttributes": [{
                                        "SourceObject_Attribute": "SaleTransactnId",
                                        "TargetObject_Attribute": "SaleTransactnId"
                                   }],
                                   "TargetObject": "SaleItems",
                                   "Cascade": "false"
                              },
                              {
                                   "RelationshipAttributes": [{
                                        "SourceObject_Attribute": "SaleTransactnId",
                                        "TargetObject_Attribute": "SaleTransactnId"
                                   }],
                                   "TargetObject": "SalePayments",
                                   "Cascade": "false"
                              },
                              {
                                   "RelationshipAttributes": [{
                                        "SourceObject_Attribute": "SaleTransactnId",
                                        "TargetObject_Attribute": "SaleTransactnId"
                                   }],
                                   "TargetObject": "SplitSalePayment",
                                   "Cascade": "false"
                              }
                         ]},
                         "InputOperations": {
                              "insert": {
                                   "isRoot": ["true"],
                                   "Children": [
                                        "SaleItems",
                                        "SalePayments",
                                        "SplitSalePayment"
                                   ]
                              },
                              "update": {
                                   "isRoot": ["true"],
                                   "Children": [
                                        "SalePayments",
                                        "SaleItems"
                                   ]
                              },
                              "delete": {"isRoot": ["true"]}
                         },
                         "Pk_Columns": [
                              "SaleTransactnId",
                              "MemberID",
                              "TransactionType",
                              "CountryID"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "EmpID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsReturn"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsSaleVoid"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LocationID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "MeetingDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MeetingOccurID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "SaleDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "double",
                                   "Name": "TotalSalePrice"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "double",
                                   "Name": "TotalSalePriceNew"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "double",
                                   "Name": "TotalSaleTax"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SaleTransactnId",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Response"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "RegNumber"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsServiceProvider"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsReturnTransaction"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "isVoidAllowed"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "TransactionType",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsEmployeeSale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "EmployeeNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsPreActivated"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "HasSplitPayment"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "double",
                                   "Name": "SubsidyAmount"
                              }
                         ],
                         "Name": "SaleDetails"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {
                              "insert": {"Parents": ["SaleDetails"]},
                              "update": {"Parents": ["SaleDetails"]}
                         },
                         "Pk_Columns": ["ClientSaleItemId"],
                         "Columns": [
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ProductID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "double",
                                   "Name": "AdjustTotal"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "double",
                                   "Name": "CalcTotal"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CouponCode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsUpload"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsSaleItemVoid"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MissWeekPassNo"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "OfrCouponCode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "OfferId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "PrepaidCoupNo"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ProductSku"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Quantity"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "OriginalQuantity"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ReasonCode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "double",
                                   "Name": "UnitPrice"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "double",
                                   "Name": "UnitPriceTax"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SaleTransactnId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Id"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ProductType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsReturnItem"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ReturnQuantity"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ClientSaleItemId",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "IsFailedMPVoucher"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ReasonId"
                              }
                         ],
                         "Name": "SaleItems"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {
                              "insert": {"Parents": ["SaleDetails"]},
                              "update": {"Parents": ["SaleDetails"]}
                         },
                         "Pk_Columns": ["SalePaymentID"],
                         "Columns": [
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "double",
                                   "Name": "Amount"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "PaymentDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Type"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SaleTransactnId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "RefundAmount"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsRefundAmount"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "AuthorizationCode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CCLastFourDigits"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CardType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "ExpirationDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "HasToken"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "InvoiceNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ReferenceNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "RequestId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Token"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "TokenExpirationDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "TransactionStatus"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "TransactionType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsTrack"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CardSignature"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsIngenicoPayment"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SalePaymentID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PaymentGateway"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "NoOfCheques"
                              }
                         ],
                         "Name": "SalePayments"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {
                              "insert": {"isRoot": ["true"]},
                              "update": {"isRoot": ["true"]},
                              "getupdated": {"isRoot": ["true"]}
                         },
                         "Pk_Columns": [
                              "ID",
                              "MemberID",
                              "CountryID"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "EmployeeID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "EmployeeName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "EntryDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "NoteTypeID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Note"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "LocationID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID",
                                   "IsPrimaryKey": true
                              }
                         ],
                         "Name": "NoteDetails"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {"insert": {"isRoot": ["true"]}},
                         "Pk_Columns": [
                              "MemberID",
                              "Type"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LocationID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "MeetingDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MeetingOccurrenceID"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ReferredByMemberID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ReferredByRegistrationNumber"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Type",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              }
                         ],
                         "Name": "RefferalDetails"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {"insert": {"isRoot": ["true"]}},
                         "Pk_Columns": [
                              "MemberID",
                              "ActivationDate",
                              "ActivationStatus",
                              "CouponCode",
                              "ID"
                         ],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SaleTransactnId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MtngOccrID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LocationID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "PreactivationDate"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "string",
                                   "Name": "ActivationDate",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "MeetingDate"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "string",
                                   "Name": "ActivationStatus",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CouponCode",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "ExpirationDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PassType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PassDuration"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "ID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "IsCurrentSyncData"
                              }
                         ],
                         "Name": "PreActivation"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {"insert": {"Parents": ["SaleDetails"]}},
                         "Pk_Columns": ["SplitID"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "SplitID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SplitType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "double",
                                   "Name": "SplitAmount"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "SplitNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SaleTransactnId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              }
                         ],
                         "Name": "SplitSalePayment"
                    }
               ],
               "Strategy": "OTA_SYNC",
               "ScopeDatabaseName": "10000169166677bc1",
               "isHierarchical": true,
               "DataSource": "7693efa9-08de-430d-a233-88481a1b13bd"
          },
          {
               "ScopeName": "LookUpTables",
               "ScopeTables": [
                    {
                         "Relationships": {},
                         "Pk_Columns": ["locationno"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "locationno",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "zip"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "displayvalue"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "lastSelected"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "ModifiedLast"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "City"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "StateId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "AreaSiteNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "locationTypeId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsActive"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LocationID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsTaxCollected"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsCreditCardEnabled"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "MPActivationEnabled"
                              }
                         ],
                         "Name": "Location"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["meetingTypeId"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "meetingTypeId",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "countryCode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "meetingTypeDesc"
                              }
                         ],
                         "Name": "MeetingTypeLookup"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["ID"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "UserName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Password"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "FirstName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "LastName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "EmployeeNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "EmployeeID"
                              },
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "string",
                                   "Name": "ID",
                                   "IsPrimaryKey": true
                              }
                         ],
                         "Name": "UserDetailsLookup"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["ID"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "ID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MeetingOccID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "MeetingDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MeetingStatus"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "LocationID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "DTCTime"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "DayCodeID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MeetingTypeID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "DayTimeCodeID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              }
                         ],
                         "Name": "MeetingInstance"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["id"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "updatedLast"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "isSyncSuccess"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LocationID"
                              }
                         ],
                         "Name": "SyncLookUp"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["Id"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ProductSKU"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MaxQuantity"
                              }
                         ],
                         "Name": "ProductMaxQuantity"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["ID"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "ID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "locationno"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "EmployeeNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              }
                         ],
                         "Name": "SavedLocation"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["ID"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "ID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "ActiveFromDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsActive"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SettingName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsApplicableToUI"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "LanguageId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SettingDescription"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SettingTypeName"
                              }
                         ],
                         "Name": "AppSettingLookUp"
                    }
               ],
               "Strategy": "OTA_SYNC",
               "ScopeDatabaseName": "10000169166677bc1",
               "DataSource": "7693efa9-08de-430d-a233-88481a1b13bd"
          },
          {
               "ScopeName": "Logger",
               "ScopeTables": [
                    {
                         "Relationships": {},
                         "Pk_Columns": ["id"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "user"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "action"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "description"
                              }
                         ],
                         "Name": "Log"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["id"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "user"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "errortype"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "description"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "errorcode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "name"
                              }
                         ],
                         "Name": "ExceptionDetail"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["Id"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "Id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "blob",
                                   "Name": "MonitorJSON"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              }
                         ],
                         "Name": "MonitorLogging"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["ID"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "ID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SyncObject"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ErrorCode"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ErrorType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ErrorMessage"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Key"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SyncSessionID"
                              }
                         ],
                         "Name": "SyncErrorLog"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["ID"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "ID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Key"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "RowsDeleted"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "RowsFailedToUpload"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "RowsInserted"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "RowsUpdated"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "RowsUploaded"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SyncObject"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SyncSessionID"
                              }
                         ],
                         "Name": "SyncFeedback"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["ID"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "ID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "IsIngenico"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Deviceid"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ReaderName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "ReaderID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "LastPairedTime"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "CreatedTime"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "LastConnectedTime"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              }
                         ],
                         "Name": "CcDeviceInfo"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["SerialNO"],
                         "Columns": [
                              {
                                   "Length": 50,
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "char",
                                   "Name": "SerialNO",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "PeripheralType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "GateWayID"
                              },
                              {
                                   "Length": 100,
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "char",
                                   "Name": "Salt"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "DateModified"
                              },
                              {
                                   "Length": 50,
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "PaymentType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              }
                         ],
                         "Name": "PeripheralInfo"
                    }
               ],
               "Strategy": "OTA_SYNC",
               "ScopeDatabaseName": "10000169166677bc1",
               "DataSource": "7693efa9-08de-430d-a233-88481a1b13bd"
          },
          {
               "ScopeName": "MeetingSyncScope",
               "ScopeTables": [{
                    "Relationships": {},
                    "Pk_Columns": ["ID"],
                    "Columns": [
                         {
                              "IsNullable": false,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "ID",
                              "IsPrimaryKey": true
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "BackOfficeRefID"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "DTCTime"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "DayCodeID"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "DayTimeCodeID"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "Description"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "DisplayValue"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "date",
                              "Name": "EndDate"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "EndTime"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "boolean",
                              "Name": "IsPersnlMeeting"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "LeaderID"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "LineOfBsinessID"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "LocationID"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "date",
                              "Name": "MeetingDate"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "MeetingNumber"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "MtingOcrncStsID"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "MeetingStatus"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "MtingTerminalID"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "MeetingTypeID"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "date",
                              "Name": "StartDate"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "TallyStatus"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "TransactionType"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "date",
                              "Name": "Date"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "isTimesheetModified"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "Locale"
                         },
                         {
                              "IsNullable": true,
                              "Autogenerated": "false",
                              "type": "string",
                              "Name": "CountryID"
                         }
                    ],
                    "Name": "Meetings"
               }],
               "Strategy": "OTA_SYNC",
               "ScopeDatabaseName": "10000169166677bc1",
               "DataSource": "7693efa9-08de-430d-a233-88481a1b13bd"
          },
          {
               "ScopeName": "Tally",
               "ScopeTables": [
                    {
                         "Relationships": {"OneToMany": [{
                              "RelationshipAttributes": [{
                                   "SourceObject_Attribute": "Id",
                                   "TargetObject_Attribute": "TallyMeetingID"
                              }],
                              "TargetObject": "BankDepositDetails",
                              "Cascade": "true"
                         }]},
                         "InputOperations": {"insert": {
                              "isRoot": ["true"],
                              "Children": ["BankDepositDetails"]
                         }},
                         "Pk_Columns": ["Id"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MeetingId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "MeetingDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "Cash"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "Checks"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "CreditCard"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "CreditSlipsRedeemed"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "CreditSlipsIssued"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "DebitCardInteract"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "BankCollected"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "DifferenceReason"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "DifferenceAmount"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "TotalSubsidyAmount"
                              }
                         ],
                         "Name": "TallyMeeting"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {"insert": {"isRoot": ["true"]}},
                         "Pk_Columns": ["Id"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MeetingId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "MeetingDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "EmpId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "EmpRole"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "EmpNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "EmpName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "TimeIn"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "TimeOut"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "BreakIn"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "BreakOut"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MeetingSetup"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MentorTraineeName"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              }
                         ],
                         "Name": "TallyTimesheet"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {"insert": {"isRoot": ["true"]}},
                         "Pk_Columns": ["id"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "MeetingDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MeetingOccrID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "CurrentAttNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "CurrentAttAmount"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MissedAtt"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "MissedAmount"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "EnrollAtt"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "EnrollAmount"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "PaidLifeAtt"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "PaidLifAmount"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "PrepaidAtt"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "FreeLifAtt"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "TotalPaidAtt"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "TotalMemberAtt"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "TotalMemberFees"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "LTPrepaidMember"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              }
                         ],
                         "Name": "TallyMeetingFee"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {"insert": {"isRoot": ["true"]}},
                         "Pk_Columns": ["id"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "MeetingDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MeetingOccrID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "MemberFees"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "Prepayment"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "ProductSales"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "ProductReturn"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "EmployeeSales"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "SalesTax"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "TotalSales"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              }
                         ],
                         "Name": "TallySales"
                    },
                    {
                         "Relationships": {},
                         "InputOperations": {"insert": {"Parents": ["TallyMeeting"]}},
                         "Pk_Columns": ["ID"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "string",
                                   "Name": "ID",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "DepositNumber"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "TallyMeetingID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "DepositDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "DepositAmount"
                              }
                         ],
                         "Name": "BankDepositDetails"
                    }
               ],
               "Strategy": "OTA_SYNC",
               "ScopeDatabaseName": "10000169166677bc1",
               "isHierarchical": true,
               "DataSource": "a2166e55-93ea-429a-831c-f9c8ff7e7456"
          },
          {
               "ScopeName": "TallySyncScope",
               "ScopeTables": [
                    {
                         "Relationships": {},
                         "Pk_Columns": ["Id"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MeetingOccurrenceID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "date",
                                   "Name": "MeetingDate"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Coupons"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Staying"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "TenPercent"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "FivePercent"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Goal"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Lifetime"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "Losing"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "float",
                                   "Name": "TotalLoss"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MonthlyPassesSold"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "TwentyWeekPassesSold"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "MonthlyPassesActivated"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "ThreeMonthsPassesActivated"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "OneMonthPassesActivated"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "EmployeeAttendance"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "int",
                                   "Name": "SixMonthsPassesActivated"
                              }
                         ],
                         "Name": "TallySummary"
                    },
                    {
                         "Relationships": {},
                         "Pk_Columns": ["Id"],
                         "Columns": [
                              {
                                   "IsNullable": false,
                                   "Autogenerated": "true",
                                   "type": "int",
                                   "Name": "Id",
                                   "IsPrimaryKey": true
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MeetingId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberId"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MemberType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "SubType"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MissweekPass"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Flow"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Sku"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "UnitPrice"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "IspaidLifetime"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "IsAtndgMeeting"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "weightloss"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "isSenior"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "boolean",
                                   "Name": "isFromMissWeek"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "MilestoneID"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "Locale"
                              },
                              {
                                   "IsNullable": true,
                                   "Autogenerated": "false",
                                   "type": "string",
                                   "Name": "CountryID"
                              }
                         ],
                         "Name": "TallyInfo"
                    }
               ],
               "Strategy": "OTA_SYNC",
               "ScopeDatabaseName": "10000169166677bc1",
               "DataSource": "a2166e55-93ea-429a-831c-f9c8ff7e7456"
          }
     ],
     "ArrayOfDataSource": [
          {
               "ID": "7693efa9-08de-430d-a233-88481a1b13bd",
               "type": "JSON"
          },
          {
               "ID": "a2166e55-93ea-429a-831c-f9c8ff7e7456",
               "type": "JSON"
          }
     ]
}
//**********************************End Scope definition************************
