//
//  SignViewController.h
//  DrawPad
//
//  Created by ami.desai on 19/10/16.
//  Copyright © 2016 Ray Wenderlich. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SignPadDelegate
-(void) getImageBase64Str:(NSString*) base64str;
@end

@interface SignView : UIView {

    CGPoint lastPoint;
    CGFloat red;
    CGFloat green;
    CGFloat blue;
    CGFloat brush;
    CGFloat opacity;
    BOOL mouseSwiped;
    BOOL validBegin;
}
@property (assign, nonatomic) IBOutlet UIImageView *mainImage;
@property (assign, nonatomic) IBOutlet UIImageView *tempDrawImage;
@property (assign, nonatomic) IBOutlet UIView *mainView;
@property (assign, nonatomic) IBOutlet UILabel *lblplaceHolder;

@property (assign, nonatomic) id<SignPadDelegate> signPadDelegate;
- (IBAction)reset:(id)sender;
- (IBAction)save:(id)sender;
- (IBAction)close:(id)sender;
-(void) setPenColor;
@end
