//
//  BarcodeReader.h
//  QRCodeReader
//


#import <Foundation/Foundation.h>

#import "lglobals.h"
#import "SignView.h"

@interface SignPad : NSObject<SignPadDelegate>
{
    UIView *modelView;
}
@property (nonatomic, retain) CallBack *callbackObj;

+(id)init;
-(void) openSignPad:(CallBack *)callbackObj;
@end
