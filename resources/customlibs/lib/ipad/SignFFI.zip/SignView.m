//
//  SignViewController.m
//  DrawPad
//
//  Created by ami.desai on 19/10/16.
//  Copyright © 2016 Ray Wenderlich. All rights reserved.
//

#import "SignView.h"

@interface SignView ()

@end

@implementation SignView


@synthesize mainImage;
@synthesize tempDrawImage;
@synthesize mainView;
@synthesize lblplaceHolder;

-(void) setPenColor
{
    red = 0.0/255.0;
    green = 0.0/255.0;
    blue = 0.0/255.0;
    brush = 2.0;
    opacity = 1.0;
    self.lblplaceHolder.text = @"Sign here";
}


- (IBAction)reset:(id)sender {
    
    
    self.lblplaceHolder.text = @"Sign here";
    self.mainImage.image = nil;
    self.tempDrawImage.image = nil;
}

- (IBAction)close:(id)sender
{
    
    [self removeFromSuperview];
    [_signPadDelegate getImageBase64Str:@""];
}
- (IBAction)save:(id)sender {
    NSString *imageBase64 = @"";
    if(self.mainImage.image != nil) {
        UIGraphicsBeginImageContextWithOptions(self.mainImage.bounds.size, NO, 0.0);
        [self.mainImage.image drawInRect:CGRectMake(0, 0, self.mainImage.frame.size.width, self.mainImage.frame.size.height)];
        UIImage *SaveImage = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        imageBase64 =  [UIImagePNGRepresentation(SaveImage) base64EncodedStringWithOptions:NSDataBase64Encoding64CharacterLineLength];//
        [self.superview removeFromSuperview];
        
    }
    
    [_signPadDelegate getImageBase64Str:imageBase64];
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    if (CGRectContainsPoint(self.mainView.frame, point)) {
        self.lblplaceHolder.text = @"";
        mouseSwiped = NO;
        validBegin = YES;
        lastPoint = [touch locationInView:self.mainView];
    }else{
        validBegin = NO;
    }
    
    
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    if (validBegin && CGRectContainsPoint(self.mainView.frame, point)) {
        mouseSwiped = YES;
        UITouch *touch = [touches anyObject];
        CGPoint currentPoint = [touch locationInView:self.mainView];
        
        UIGraphicsBeginImageContext(self.mainView.frame.size);
        [self.tempDrawImage.image drawInRect:CGRectMake(0, 0, self.mainView.frame.size.width, self.mainView.frame.size.height)];
        CGContextMoveToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y);
        CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), currentPoint.x, currentPoint.y);
        CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
        CGContextSetLineWidth(UIGraphicsGetCurrentContext(), brush );
        CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), red, green, blue, 1.0);
        CGContextSetBlendMode(UIGraphicsGetCurrentContext(),kCGBlendModeNormal);
        
        CGContextStrokePath(UIGraphicsGetCurrentContext());
        self.tempDrawImage.image = UIGraphicsGetImageFromCurrentImageContext();
        [self.tempDrawImage setAlpha:opacity];
        UIGraphicsEndImageContext();
        
        lastPoint = currentPoint;
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    if (validBegin && CGRectContainsPoint(self.mainView.frame, lastPoint)) {
        if(!mouseSwiped) {
            UIGraphicsBeginImageContext(self.mainView.frame.size);
            [self.tempDrawImage.image drawInRect:CGRectMake(0, 0, self.mainView.frame.size.width, self.mainView.frame.size.height)];
            CGContextSetLineCap(UIGraphicsGetCurrentContext(), kCGLineCapRound);
            CGContextSetLineWidth(UIGraphicsGetCurrentContext(), brush);
            CGContextSetRGBStrokeColor(UIGraphicsGetCurrentContext(), red, green, blue, opacity);
            CGContextMoveToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y);
            CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), lastPoint.x, lastPoint.y);
            CGContextStrokePath(UIGraphicsGetCurrentContext());
            CGContextFlush(UIGraphicsGetCurrentContext());
            self.tempDrawImage.image = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
        }
        
        UIGraphicsBeginImageContext(self.mainImage.frame.size);
        [self.mainImage.image drawInRect:CGRectMake(0, 0, self.mainView.frame.size.width, self.mainView.frame.size.height) blendMode:kCGBlendModeNormal alpha:1.0];
        [self.tempDrawImage.image drawInRect:CGRectMake(0, 0, self.mainView.frame.size.width, self.mainView.frame.size.height) blendMode:kCGBlendModeNormal alpha:opacity];
        self.mainImage.image = UIGraphicsGetImageFromCurrentImageContext();
        self.tempDrawImage.image = nil;
        UIGraphicsEndImageContext();
    }
}


@end
