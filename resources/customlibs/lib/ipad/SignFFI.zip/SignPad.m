//
//  BarcodeReader.m
//  QRCodeReader
//


#import "SignPad.h"
#import <QuartzCore/QuartzCore.h>
@implementation SignPad

+(id)init
{
    
    static SignPad *signPad = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        signPad = [[self alloc] init];
    });
    return signPad;
 
}
-(void) getImageBase64Str:(NSString*) base64str
{
    NSArray * result = [[NSArray alloc] initWithObjects:base64str, nil];
    executeClosure(self.callbackObj, result, NO);
}



-(void) openSignPad:(CallBack *)callbackObj
{
    self.callbackObj = callbackObj;
    dispatch_async(dispatch_get_main_queue(), ^{
    UIViewController *controller=[[UIViewController alloc] initWithNibName:@"SignView" bundle:nil];
    SignView* signView=(SignView*)controller.view;
    
    signView.signPadDelegate=self;
    
     UINavigationController *nav = (UINavigationController *)[UIApplication sharedApplication].keyWindow.rootViewController;
     UIViewController *currentViewController = nav.topViewController;
    
    CGRect frame = currentViewController.view.frame;
    
    modelView = [[[UIView alloc] initWithFrame:CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, frame.size.height)] autorelease];
    
    [currentViewController.view addSubview:modelView];
    [modelView addSubview:signView];
    
    [signView setPenColor];
    
    signView.frame = CGRectMake(0, 0, 475, 299);
    signView.center =currentViewController.view.center;
   // signView.mainImage.frame=signView.frame;
    //signView.tempDrawImage.frame=signView.frame;
    
    signView.layer.cornerRadius = 10;
    signView.layer.masksToBounds = YES;
    
    signView.layer.borderColor = [UIColor lightGrayColor].CGColor;
    signView.layer.borderWidth = 0.1f;
    
    [controller release];
     });
}

-(id)copyWithZone:(NSZone *)zone

{
    
    return self;
    
}



-(id)retain

{
    
    return self;
    
}



-(NSUInteger)retainCount

{
    
    return NSUIntegerMax; //denotes an object that cannot be released
    
}



-(oneway void)release

{
    
    //do nothing
    
}



-(id)autorelease

{
    
    return self;
    
}
@end
