//
//  IMSBaseViewController.h
//  IngenicoSDKTestApp
//
//  Copyright © 2016 RoamData. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "CallBack.h"


@interface KonyBridge : NSObject
+(void) sendDataToApp:(id)data callback:(CallBack *)pairCallbackObj;
@end
