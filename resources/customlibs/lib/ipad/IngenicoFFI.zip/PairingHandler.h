//
//  PairingHandler.h

#import <UIKit/UIKit.h>
#import <RUA_MFI/RUA.h>
#import <Foundation/Foundation.h>
#import <IngenicoMposSdk_MFI/Ingenico.h>
#import <MessageUI/MessageUI.h>
#import <IngenicoMposSdk_MFI/IMSUtil.h>
#import "CallBack.h"
#import "KonyBridge.h"
#import "SVProgressHUD.h"
#import "lglobals.h"


@interface PairingHandler : NSObject <RUADeviceStatusHandler, RUAAudioJackPairingListener>

@property(nonatomic, retain) CallBack * pairCallbackObj; //Kony callback funnctin for sending pairing info.
@property(nonatomic, retain) CallBack * connectCallbackObj; //Kony callback funnctin for sending connection info.
@property(nonatomic, retain) CallBack * paymentCallbackObj; //Kony callback funnctin for sending Payment status and transaction info.
@property(nonatomic, retain) CallBack * voidCallbackObj; //Kony callback funnctin for sending transaction void staus info.
@property(nonatomic, retain) CallBack * loginCallbackObj; //Kony callback funnctin for sending ingenico gatway login status info.
@property(nonatomic, retain) CallBack * deviceCallbackObj; //Kony callback funnctin for sending reader info.
@property(nonatomic, retain) CallBack * batteryCallbackObj;
@property(nonatomic, retain) RUADevice *selectedRUADevice;

-(void)setLoggedIn:(bool)loggedin;

-(bool)isLoggedIn;

-(void)initiazeDevice:(NSString *)baseURL apiKey:(NSString *)apiKey clientVersion:(NSString *)clientVersion userName:(NSString *)userName password:(NSString *)password pairCallBack:(CallBack*)pairCallBack connCallback:(CallBack*)connCallback isConnInBG:(BOOL)isConnInBG isRepairingRequest:(BOOL)isRepairingRequest batteryCallback:(CallBack*)batteryCallback;

-(void)connectDevice:(CallBack*)connectCallBack;

-(void) swipeCardAndProcessPayment:(NSInteger *)amount merchantReferenceCode:(NSString *)merchantReferenceCode enrollToken:(BOOL)enrollToken tokenReferenceNo:(NSString *)tokenReferenceNo memberData:(NSDictionary *)memberData paymentCallback:(CallBack*)paymentCallback;

-(void) voidPayment:(NSString *)transactionId merchantReferenceCode:(NSString *)merchantReferenceCode voidCallback:(CallBack*)voidCallback;

-(void) generateHashPassword:(NSString*)password salt:(NSString*)salt keyLength:(NSInteger*)keyLength prf:(NSInteger*)prf iteration:(NSInteger*)iteration loginCallback:(CallBack*)loginCallback;

-(void) loginAndProcess:(NSInteger)totalAmount merchantReferenceCode:(NSString *)merchantReferenceCode enrollToken:(BOOL)enrollToken tokenReferenceNo:(NSString *)tokenReferenceNo memberData:(NSDictionary *)memberData transactionID:(NSString *)transID;

-(void) login:(NSString *)userName password:(NSString *)password loginCallback:(CallBack*)loginCallback;

-(void) changeLoginPassword:(NSString *)oldPassword newPassword:(NSString *)newPassword loginCallback:(CallBack*)loginCallback;

-(void)setLoginCredential:(NSString *)userName password:(NSString *)password isLoginSuccess:(BOOL)isLoginSuccess loginCallback:(CallBack*)loginCallback;

-(void) generateSalt256:(CallBack*)loginCallback;

-(void)processTransactionToken:(NSInteger)totalAmount;

-(void) saveDeviceDetailTOKeychain:(NSString*) deviceName deviceIdentifier:(NSString*) deviceIdentifier;

-(void) getDeviceDetailFromKeychain:(CallBack*)deviceInfoCallbackObj;

-(void)resetPairing;


@end
