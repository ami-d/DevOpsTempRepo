//
//  PairingHandler.h.m
//
#define RUA_MFI
#import "PairingHandler.h"
#import "DeviceManagementHelper.h"
#import <objc/runtime.h>
#import <CommonCrypto/CommonKeyDerivation.h>



#define LSSTRING(str) NSLocalizedString(str, nil)



static NSString *USERNAME = @"";
static NSString *PASSWORD = @"";
static NSTimeInterval BATTERYCHECK = 55.0f;
static bool isDeviceConnected; /* To set the connection status of the reader */
static bool isLoggedIn; /* To set the ingenico gateway login status */

static bool isPairedDeviceFound; /* Set to true if reader info found in local DB or iOS keychain */

static bool initDeviceDone; /* Set to true once the mPOS sdk initiazed */
static PairingHandler *currentVC;

static bool isiOSBTOFF; /* Set to true when iOS bluetooth get turned OFF */
static bool pairedDeviceScanned; /* Set to true when reader found connected to iOS setting over bluetooth */


static bool isConnectedViaBT;

#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)

@interface PairingHandler ()<DeviceManagementDelegate,RUAReleaseHandler>
{
    IMSPaymentDevice *ingenicoDevice;
    
    TransactionOnDone doneCallback;
    UpdateProgress progressCallback;
    ApplicationSelectionHandler applicationSelectionCallback;
    NSTimer *swipeTimer;
    NSTimer *batteryTimer;
    NSString *passkey;
    DeviceManagementHelper *deviceManager;
    bool isConnectionInBG; /* Check the connectin type - Manual/Auto connection */
    bool isRepairingRequested; /* Identify the re-paire request intiated or not */
    RUADeviceType selectedDeviceType;
}
@end

@implementation PairingHandler

@synthesize pairCallbackObj,connectCallbackObj,paymentCallbackObj,voidCallbackObj,loginCallbackObj,deviceCallbackObj,selectedRUADevice,batteryCallbackObj;



+(id) init
{
    /* Make a singleton instance. */
    static PairingHandler *pairingHandler = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        pairingHandler = [[self alloc] init];
    });
    return pairingHandler;
}

/*
 Get reader info from iPad keychain if avaialble
 
 @param deviceInfoCallbackObj : Kony callback function to send the reader information
 */
-(void) getDeviceDetailFromKeychain:(CallBack*)deviceInfoCallbackObj
{
    NSLog(@"MEG Ingenico FFI : In getDeviceDetailFromKeychain");
    self.deviceCallbackObj = deviceInfoCallbackObj;
    deviceManager = [DeviceManagementHelper sharedInstance];
    [[DeviceManagementHelper sharedInstance] setDelegate:self];
    
    [deviceManager retrievePairedDevices];
    
    NSMutableDictionary * deviceStatus = [NSMutableDictionary dictionary];
    if(deviceManager.pairedDevice !=nil) /* If reader info found in keychain */
    {
        NSLog(@"MEG Ingenico FFI : Reader info found in Keychain = %@",deviceManager.pairedDevice.name);
        selectedRUADevice = [[RUADevice alloc] initWithName:deviceManager.pairedDevice.name withIdentifier:deviceManager.pairedDevice.identifier withCommunicationInterface:0];
        
        /* Sending reader found status as true along with reader info to KONY */
        [deviceStatus setObject:[NSNumber numberWithInteger:1]  forKey:@"isDeviceInfoFound"];
        NSMutableDictionary * deviceInfo = [NSMutableDictionary dictionary];
        [deviceInfo setObject:[NSString stringWithFormat:@"%@",selectedRUADevice.name]  forKey:@"name"];
        [deviceInfo setObject:[NSString stringWithFormat:@"%@",selectedRUADevice.identifier]  forKey:@"identifier"];
        [deviceStatus setObject:deviceInfo  forKey:@"deviceInfo"];
        
    }else{
        NSLog(@"MEG Ingenico FFI : Reader info NOT found in Keychain");
        /* Sending reader found status as false to KONY */
        [deviceStatus setObject:[NSNumber numberWithInteger:0]  forKey:@"isDeviceInfoFound"];
    }
    [KonyBridge sendDataToApp:deviceStatus callback:self.deviceCallbackObj];
}


/*
 Process the intiazation ,Pair, Re-Pair and Connection
 
 @param baseURL : hostname of the Ingenico Payment Server
 @param apiKey : API key of the client application for the Ingenico Payment Server
 @param clientVersion : version of the client application
 @param userName : merchant's username
 @param password : password
 @param pairCallBack : the callback used to indicate Pairing status
 @param connCallback : the callback used to indicate connection status
 @param isConnInBG : check the connectin type - Manual/Auto connection
 @param isRepairingRequest : identify the re-paire request intiated or not
 */
- (void)initiazeDevice:(NSString *)baseURL apiKey:(NSString *)apiKey clientVersion:(NSString *)clientVersion userName:(NSString *)userName password:(NSString *)password pairCallBack:(CallBack*)pairCallBack connCallback:(CallBack*)connCallback isConnInBG:(BOOL)isConnInBG isRepairingRequest:(BOOL)isRepairingRequest batteryCallback:(CallBack*)batteryCallback
{
    NSLog(@"MEG Ingenico FFI : In initiazeDevice");
    
    self.pairCallbackObj = pairCallBack;
    self.connectCallbackObj = connCallback;
   self.batteryCallbackObj = batteryCallback;
    isConnectionInBG = isConnInBG;
    isRepairingRequested =isRepairingRequest;
    
    
    if(!initDeviceDone){
        selectedDeviceType = RUADeviceTypeRP450c;
        [[Ingenico sharedInstance] initializeWithBaseURL:baseURL apiKey:apiKey clientVersion:clientVersion];
        [[Ingenico sharedInstance].PaymentDevice setDeviceType:selectedDeviceType];
        [[Ingenico sharedInstance].PaymentDevice initialize:self];
        [[Ingenico sharedInstance] setLogging:YES];
        [self setUpCallTransactionCallback];
        if(deviceManager == nil) {
            deviceManager = [DeviceManagementHelper sharedInstance];
            [[DeviceManagementHelper sharedInstance] setDelegate:self];
        }
        initDeviceDone=TRUE;
    }
    
    if(isRepairingRequested){
        NSLog(@"MEG Ingenico FFI : Re-Pair requested");
        dispatch_async(dispatch_get_main_queue(), ^{
            isPairedDeviceFound = FALSE;
            if(!isDeviceConnected && !isConnectionInBG){
                [[Ingenico sharedInstance].PaymentDevice releaseDevice:self];
                [self showAlertWithTitle:LSSTRING(@"strIngenicoMSGNoPair") andMessage:@""];

                //[self showPairingIndicator];
            }
        });
    }else{
        if(!isDeviceConnected && !isPairedDeviceFound) {
            NSLog(@"MEG Ingenico FFI : Reader not connected the Pairing info not found yet  %@",selectedRUADevice);
            if(selectedRUADevice != nil)
            {
                NSLog(@"MEG Ingenico FFI : Paired device found");
                isPairedDeviceFound = TRUE;
                
                /* Send pair status as true along with reader info to KONY */
                NSMutableDictionary * pairStatus = [NSMutableDictionary dictionary];
                [pairStatus setObject:[NSNumber numberWithInteger:1]  forKey:@"pairStatus"];
                NSMutableDictionary * deviceInfo = [NSMutableDictionary dictionary];
                [deviceInfo setObject:[NSString stringWithFormat:@"%@",selectedRUADevice.name]  forKey:@"name"];
                [deviceInfo setObject:[NSString stringWithFormat:@"%@",selectedRUADevice.identifier]  forKey:@"identifier"];
                [pairStatus setObject:deviceInfo  forKey:@"deviceInfo"];
                [KonyBridge sendDataToApp:pairStatus callback:self.pairCallbackObj];
                
                //[self connectToDevice:selectedRUADevice deviceType:RUADeviceTypeRP450c];
                
                /* Start accessory scanning for paired reader found connected with iOS bluetooth. */
                [self onError:@""];
                
            }else{
                NSLog(@"MEG Ingenico FFI : NO Paired device found");
                dispatch_async(dispatch_get_main_queue(), ^{
                    isPairedDeviceFound = FALSE;
                    if(!isDeviceConnected){
                        
                        /* Send pair status as false to KONY */
                        NSMutableDictionary * pairStatus = [NSMutableDictionary dictionary];
                        [pairStatus setObject:[NSNumber numberWithInteger:0]  forKey:@"pairStatus"];
                        [KonyBridge sendDataToApp:pairStatus callback:self.pairCallbackObj];
                        
                        if(!isConnectionInBG){
                            NSLog(@"MEG Ingenico FFI : Fresh Pairing starts..");
                            [self showAlertWithTitle:LSSTRING(@"strIngenicoMSGNoPair") andMessage:@""];
                            // [self showPairingIndicator];
                        }
                    }
                });
            }
        }else if(isPairedDeviceFound && !isDeviceConnected)
        {
            NSLog(@"MEG Ingenico FFI : Paired device found and the device NOT connected");
            /* Make a connection from App with the reader */
            [self connectToDevice:selectedRUADevice deviceType:selectedDeviceType];
        }else if(isDeviceConnected)
        {
            NSLog(@"MEG Ingenico FFI : Paired device found connected");
            if(pairedDeviceScanned) {
                [self showAlertWithTitle:[NSString stringWithFormat:@"%@ %@",LSSTRING(@"strIngenicoMSGMEGConn"),selectedRUADevice.name] andMessage:@""];
            }
            else {
                [self showAlertWithTitle:@"Please Remove Device from Audio jack." andMessage:@""];
            }
        }
    }
}

/*
 Show a Loading indicator and start a timer once the user opt for Pair untill the reder injected via audio jack and detected  by the SDK using onConnected() API
 */
-(void) showPairingIndicator
{
    if(!isDeviceConnected)
    {
        //[SVProgressHUD showWithStatus:@"Connect Reader into Audio jack." maskType:SVProgressHUDMaskTypeGradient];
        [SVProgressHUD show];
        [self startPairTimer];
    }
}

/*
 Makes a random 256-bit salt
 
 @param loginCallback : KONY callback function
 */
-(void) generateSalt256:(CallBack*)loginCallback
{
    self.loginCallbackObj = loginCallback;
    
    unsigned char salt[32];
    for (int i=0; i<32; i++) {
        salt[i] = (unsigned char)arc4random();
    }
    NSData *hashKeyData = [NSData dataWithBytes:salt length:32];
    
    /* Hexa decimal or hash key string from hash key data. */
    const unsigned char *buffer = (const unsigned char *)[hashKeyData bytes];
    NSString *saltString = [NSMutableString stringWithCapacity:hashKeyData.length];
    for (int i = 0; i < hashKeyData.length; ++i)
        saltString = [saltString stringByAppendingFormat:@"%02lx", (unsigned long)buffer[i]];
    
    NSLog(@"MEG Ingenico FFI : Hexa decimal SALT %@ of length = %lu", saltString,(unsigned long)saltString.length);
    
    /* Send generated SALT data to KONY */
    NSMutableDictionary * saltData = [NSMutableDictionary dictionary];
    [saltData  setObject:saltString  forKey:@"saltKey"];
    [KonyBridge sendDataToApp:saltData callback:self.loginCallbackObj];
}

/*
 Generate the hash password from plain text password
 
 @param password : Plain text password
 @param salt : The salt byte values used as input to the derivation function
 @param keyLength : The expected length of the derived key in bytes
 @param prf : The Pseudo Random Algorithm to use for the derivation iterations
 @param iteration : The number of rounds of the Pseudo Random Algorithm to use
 @param loginCallback : KONY callback function
 */
-(void) generateHashPassword:(NSString*)password salt:(NSString*)salt keyLength:(NSInteger*)keyLength prf:(NSInteger*)prf iteration:(NSInteger*)iteration loginCallback:(CallBack*)loginCallback
{
    self.loginCallbackObj = loginCallback;
    
    NSLog(@"MEG Ingenico FFI : IN generateHashPassword");
    NSLog(@"MEG Ingenico FFI : password = %@, salt = %@, keyLength = %li, prf = %li",password,salt,(unsigned long)keyLength,(unsigned long)prf);
    
    /* Salt data getting from salt string */
    NSData *saltData = [salt dataUsingEncoding:NSUTF8StringEncoding];
    
    /* Data of String to generate Hash key(hexa decimal string) */
    NSData *passwordData = [password dataUsingEncoding:NSUTF8StringEncoding];
    
    /* Hash key (hexa decimal) string data length */
    NSMutableData *hashKeyData = [NSMutableData dataWithLength:keyLength];
    
    /* Key Derivation using PBKDF2 algorithm */
    int result = CCKeyDerivationPBKDF(kCCPBKDF2,               // algorithm
                                      passwordData.bytes,           // password
                                      passwordData.length,          // passwordLength
                                      saltData.bytes,              // salt
                                      saltData.length,             // saltLen
                                      prf,       // PRF
                                      iteration,                  // rounds
                                      hashKeyData.mutableBytes, // derivedKey
                                      hashKeyData.length);      // derivedKeyLen
    
    NSLog(@"MEG Ingenico FFI : result:%d", result);
    NSLog(@"MEG Ingenico FFI : hexDecimalString %@",hashKeyData.description);
    NSLog(@"MEG Ingenico FFI : Hexa decimal string :%@ and length = %lu", hashKeyData.description,(unsigned long)hashKeyData.length);
    
    /* Hexa decimal or hash key string from hash key data */
    const unsigned char *buffer = (const unsigned char *)[hashKeyData bytes];
    NSString *hexDecimalString = [NSMutableString stringWithCapacity:hashKeyData.length];
    for (int i = 0; i < hashKeyData.length; ++i)
        hexDecimalString = [hexDecimalString stringByAppendingFormat:@"%02lx", (unsigned long)buffer[i]];
    
    /* This is the password for Ingenico login API */
    NSLog(@"MEG Ingenico FFI : Hexa decimal string :%@ and length = %lu", hexDecimalString,(unsigned long)hexDecimalString.length);
    NSString *base64String = [hashKeyData base64EncodedStringWithOptions:0];
    NSLog(@"MEG Ingenico FFI : Hexa decimal base64 :%@ and length = %lu", base64String,(unsigned long)base64String.length);
    
    /* Send generated hash password to KONY */
    NSMutableDictionary * genPassStatus = [NSMutableDictionary dictionary];
    [genPassStatus  setObject:hexDecimalString  forKey:@"hashPassword"];
    [KonyBridge sendDataToApp:genPassStatus callback:self.loginCallbackObj];
}

-(void) startBatteryTimer
{
    if (!batteryTimer) {
        NSLog(@"MEG Ingenico FFI :  Battery timer started");
        batteryTimer = [NSTimer scheduledTimerWithTimeInterval:BATTERYCHECK
                                                        target:self
                                                      selector:@selector(getDeviceBatterylevel)
                                                      userInfo:nil
                                                       repeats:YES];
    }
}
-(void) startPairTimer
{
    if (!swipeTimer) {
        NSLog(@"MEG Ingenico FFI :  Pair timer started");
        swipeTimer = [NSTimer scheduledTimerWithTimeInterval:60.0f
                                                      target:self
                                                    selector:@selector(pairTimeout)
                                                    userInfo:nil
                                                     repeats:NO];
    }
}

-(void) stopBatteryTimer
{
    NSLog(@"MEG Ingenico FFI : Battery timer stopped");
    if ([batteryTimer isValid]) {
        [batteryTimer invalidate];
    }
    batteryTimer = nil;
}

-(void) stopPairTimer
{
    NSLog(@"MEG Ingenico FFI :  Pair timer stopped");
    if ([swipeTimer isValid]) {
        [swipeTimer invalidate];
    }
    swipeTimer = nil;
    [SVProgressHUD dismiss];
}


-(void) pairTimeout
{
    NSLog(@"MEG Ingenico FFI :  Pairing TimeOut");
    if ([swipeTimer isValid]) {
        [swipeTimer invalidate];
    }
    swipeTimer = nil;
    [SVProgressHUD dismiss];
    [self showAlertWithTitle:@"" andMessage:@"Connection Timeout. Your device not connected in audio jack."];
}

-(void) cancleTransaction
{
    [[Ingenico sharedInstance].Payment abortTransaction];
    [SVProgressHUD dismiss];
}

/*
 Initiate the iOS accessories discovery which looking for paired reader get connected with iOS over bluetooth
 */
-(void) startDeviceDiscovery
{
    NSLog(@"MEG Ingenico FFI :  IN startDeviceDiscovery");
    if(!isDeviceConnected) {
        NSLog(@"MEG Ingenico FFI :  Start the Accessory scan discovey..");
        pairedDeviceScanned = NO;
        [[DeviceManagementHelper sharedInstance] initiateScan];
    }else{
        
    }
    
}

-(void) printStrLog:(NSString*)msg
{
    NSLog(@"MEG Ingenico FFI : %@",msg);
}

/*
 Login to the payment gateway and process the payment or void the transaction after login success
 
 @param totalAmount : Total Purchase amount
 @param merchantReferenceCode : Merchant's referance number
 @param enrollToken : Identiy the transaction as a new Enrollment
 @param tokenReferenceNo : Token reference number
 @param memberData : User's billing information
 @param transactionID : Transaction ID if processing Void
 */
-(void) loginAndProcess:(NSInteger)totalAmount merchantReferenceCode:(NSString *)merchantReferenceCode enrollToken:(BOOL)enrollToken tokenReferenceNo:(NSString *)tokenReferenceNo memberData:(NSDictionary *)memberData transactionID:(NSString *)transID {
    [self printStrLog:@"MEG Ingenico FFI : In loginAndProcess"];
    
    [[Ingenico sharedInstance].User loginwithUsername:USERNAME andPassword:PASSWORD onResponse:^(IMSUserProfile *user, NSError *error) {
        if(!error){
            NSLog(@"MEG Ingenico FFI : User profile after Login = %@",[[user class] description]);
            [self setLoggedIn:TRUE];
            [self printStrLog:@"Login Success"];
            if(totalAmount >= 0)
                [self processTransaction:totalAmount merchantReferenceCode:merchantReferenceCode enrollToken:enrollToken tokenReferenceNo:tokenReferenceNo memberData:memberData];
            else if(transID != nil)
                [self processVoid:transID merchantReferenceCode:merchantReferenceCode];
            
        } else{
            [self showAlertWithTitle:LSSTRING(@"strCCNotProcessed") andMessage:@""];
            [SVProgressHUD dismiss];
            [self startBatteryTimer];
            [self printStrLog:[NSString stringWithFormat:@"Login Failed with errorcode %ld",(long)error.code]];
        }
        
    }];
}


/*
 Login to the payment gateway
 
 @param userName : Merchant's username
 @param password : Passeword
 @param loginCallback : KONY callback function
 */
-(void) login:(NSString *)userName password:(NSString *)password loginCallback:(CallBack*)loginCallback
{
    self.loginCallbackObj = loginCallback;
    
    [[Ingenico sharedInstance].User loginwithUsername:userName andPassword:password onResponse:^(IMSUserProfile *user, NSError *error) {
        BOOL isLoginSuccess = FALSE;
        if(error){ /* login successfull */
            [self printStrLog:[NSString stringWithFormat:@"Login Failed with errorcode %ld",(long)error.code]];
            isLoginSuccess = FALSE;
        } else{
            isLoginSuccess = TRUE;
            NSLog(@"MEG Ingenico FFI : LOGIN Succuess = %@",[[user class] description]);
        }
        
        /* Send login status to KONY */
        NSMutableDictionary * loginStatus = [NSMutableDictionary dictionary];
        [loginStatus  setObject:[NSNumber numberWithInteger:isLoginSuccess] forKey:@"loginStatus"];
        [loginStatus  setObject:(error) ? [NSNumber numberWithInteger:error.code] : [NSNumber numberWithInteger:0]  forKey:@"ErrorCode"];
        [KonyBridge sendDataToApp:loginStatus callback:self.loginCallbackObj];
        
    }];
}

/*
 Change the Login password
 
 @param oldPassword : Existing password
 @param newPassword : New password
 @param loginCallback : KONY callback function
 */
-(void) changeLoginPassword:(NSString *)oldPassword newPassword:(NSString *)newPassword loginCallback:(CallBack*)loginCallback
{
    self.loginCallbackObj = loginCallback;
    
    [[Ingenico sharedInstance].User changePasswordWithOldPassword:oldPassword  andNewPassword:newPassword andOnDone:^(NSError *error)
     {
         BOOL isChangePasswordSuccess = FALSE;
         if(error){ /* Change password failed(code in the response will indicates the result) */
             isChangePasswordSuccess = FALSE;
             NSLog(@"MEG Ingenico FFI : Password changed failed = %ld",(long)error.code);
             
         } else{
             isChangePasswordSuccess = TRUE;
             NSLog(@"MEG Ingenico FFI : Password changed Succuess");
             
             /*Change password succeeded*/
         }
         
         /* Send status to KONY */
         NSMutableDictionary * changePwdStatus = [NSMutableDictionary dictionary];
         [changePwdStatus  setObject:[NSNumber numberWithInteger:isChangePasswordSuccess] forKey:@"ChangePasswordStatus"];
         [changePwdStatus  setObject:(error) ? [NSNumber numberWithInteger:error.code] : [NSNumber numberWithInteger:0]  forKey:@"ErrorCode"];
         [KonyBridge sendDataToApp:changePwdStatus callback:self.loginCallbackObj];
         
     }];
}

/*
 Store Login credential info after successfull login
 
 @param userName : Merchant's username
 @param password : Passeword
 @param isLoginSuccess : Indicate login successfull or not
 @param loginCallback : KONY callback function
 */
-(void)setLoginCredential:(NSString *)userName password:(NSString *)password isLoginSuccess:(BOOL)isLoginSuccess loginCallback:(CallBack*)loginCallback
{
    NSLog(@"MEG Ingenico FFI : IN setLoginCredential");
    self.loginCallbackObj = loginCallback;
    [self setLoggedIn:isLoginSuccess];
    USERNAME = userName;
    PASSWORD = password;
    
    /* Send login status to KONY */
    NSMutableDictionary * loginStatus = [NSMutableDictionary dictionary];
    [KonyBridge sendDataToApp:loginStatus callback:self.loginCallbackObj];
}

/*
 Establish the connection from the APP with the Paird reader
 
 @param connectCallBack : KONY callback function
 */
- (void)connectDevice:(CallBack*)connectCallBack
{
    self.connectCallbackObj = connectCallBack;
    [self connectToDevice:selectedRUADevice deviceType:selectedDeviceType];
}

/*
 Get the existing Parent View/Form to display the popup and Alerts from FFI
 
 @param connectCallBack : KONY callback function
 */
- (UIViewController*) topMostController
{
    UIViewController *topController = [UIApplication sharedApplication].keyWindow.rootViewController;
    
    /*    while (topController.presentedViewController) {
     topController = topController.presentedViewController;
     }*/
    
    return topController;
}


/*
 Start the Pairing process
 */
-(void) startPairingProcess
{
    NSLog(@"MEG Ingenico FFI : IN startPairingProcess");
    [[DeviceManagementHelper sharedInstance] stopScan];
    
    passkey = nil;
    if(isDeviceConnected){
        [[[Ingenico sharedInstance] PaymentDevice] requestPairing:self];
        if(&UIApplicationOpenSettingsURLString)
        {
            UIAlertController *alertController = [UIAlertController
                                                  alertControllerWithTitle:@""
                                                  message:LSSTRING(@"strIngenicoMSGStartPairing")
                                                  preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction *goSettingsAction = [UIAlertAction actionWithTitle:@"Go to Settings" style:UIAlertActionStyleCancel handler:^(UIAlertAction * action) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
                /*NSURL *url = [NSURL URLWithString:@"prefs:root=Bluetooth"];
                 if (![[UIApplication sharedApplication] canOpenURL:url])
                 {   //iOS 10+
                 url = [NSURL URLWithString:@"App-Prefs:root=Bluetooth"];
                 }else{
                 [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
                 }
                 [[UIApplication sharedApplication] openURL:url];*/
                [[self topMostController] dismissViewControllerAnimated:YES completion:nil];
            }];
            [alertController addAction:goSettingsAction];
            [[self topMostController] presentViewController:alertController animated:YES completion:nil];
        }
    }
    else if(!isDeviceConnected){
        [self showAlertWithTitle:LSSTRING(@"strIngenicoMSGConnectDevViaAudioJack") andMessage:@""];
    }
}
/*
 - (void)setupDevice:(NSInteger)totalAmount transactionID:(NSString *)transID {
 if([[[Ingenico sharedInstance] PaymentDevice] isSetupRequired]) {
 [SVProgressHUD showWithStatus:@"Setting up device!" maskType:SVProgressHUDMaskTypeGradient];
 [[Ingenico sharedInstance].PaymentDevice setup:^(NSError *error) {
 [SVProgressHUD dismiss];
 if(!error){
 [SVProgressHUD showSuccessWithStatus:@"Setup completed" maskType:SVProgressHUDMaskTypeGradient];
 if(totalAmount >= 0)
 [self processTransaction:totalAmount];
 else if(transID != nil)
 [self processVoid:transID];
 }
 else{
 NSLog(@"Setup failed with error %@", error);
 [SVProgressHUD showErrorWithStatus:@"Setup failed" maskType:SVProgressHUDMaskTypeGradient];
 }
 }];
 }else{
 NSLog(@"Setup not required");
 if(totalAmount >= 0)
 [self processTransaction:totalAmount];
 else if(transID != nil)
 [self processVoid:transID];
 }
 }
 */
- (void)setLoggedIn:(bool)loggedin{
    isLoggedIn = loggedin;
}

- (bool)isLoggedIn{
    return isLoggedIn;
}


/*
 Get the reader Battery level when connected
 */
-(void)getDeviceBatterylevel
{
    NSLog(@"MEG Ingenico FFI : IN getDeviceBatterylevel");
    [[Ingenico sharedInstance].PaymentDevice getDeviceBatteryLevel:^(NSInteger batteryLevel, NSError *error) {
        if(error){
            /* Refresh the connection in case of App resume from background and inbetween the reader status changed (connected/disconnected) */
            NSLog(@"Error in getting battery status");
            [self stopBatteryTimer];
            isConnectionInBG = TRUE;
            [self connectToDevice:selectedRUADevice deviceType:selectedDeviceType];
        }else{
            NSLog(@"battery status = %lu",(long)batteryLevel);
            NSMutableDictionary * batteryStatus = [NSMutableDictionary dictionary];
            [batteryStatus  setObject:[NSNumber numberWithInteger:batteryLevel]  forKey:@"batteryStatus"];
            [KonyBridge sendDataToApp:batteryStatus callback:self.batteryCallbackObj];
            
        }
    }];
    
}

#pragma RUADeviceStatus Implementation
/*
 Invoked when the reader is connected.
 */
- (void)onConnected {
    NSLog(@"MEG Ingenico FFI : IN onConnected");

    [[DeviceManagementHelper sharedInstance] stopScan];
    [SVProgressHUD dismiss];
    NSLog(@"MEG Ingenico FFI : %@ Connected",selectedRUADevice.name);
    isDeviceConnected = YES;
    isiOSBTOFF = NO;
    
    NSMutableDictionary * connStatus = [NSMutableDictionary dictionary];
    
    if(isPairedDeviceFound && pairedDeviceScanned) /* If the Paired reader found connected via bluetooth */
    {
        NSLog(@"MEG Ingenico FFI : Reader Connected via Bluetooth");
        [self getDeviceBatterylevel];
        [self startBatteryTimer];
        
        /* Send connection status as TRUE along with reader info to KONY */
        [connStatus  setObject:[NSNumber numberWithInteger:1]  forKey:@"connStatus"];
        [connStatus  setObject:[NSString stringWithFormat:@"%@",selectedRUADevice.name]  forKey:@"deviceName"];
        [connStatus  setObject:[NSString stringWithFormat:@"%@",selectedRUADevice.identifier]  forKey:@"devicdeID"];
        [KonyBridge sendDataToApp:connStatus callback:self.connectCallbackObj];
        
    }else if(!isPairedDeviceFound){
        NSLog(@"MEG Ingenico FFI : Reader Connected via Audio jack for pairing");
        [self stopPairTimer];
        [self startPairingProcess];
    }else{
        /* Send connection status as FALSE to ignore the connection by KONY as the reader could be connected in the audio jack which is already paired and expected to be connected via blutooth only */
        isDeviceConnected = NO;
        [connStatus  setObject:[NSNumber numberWithInteger:0]  forKey:@"connStatus"];
        [KonyBridge sendDataToApp:connStatus callback:self.connectCallbackObj];
    }
}

/*
 Invoked when the reader is disconnected (unplugged).
 */
- (void)onDisconnected {
    NSLog(@"MEG Ingenico FFI : Reader DisConnected");
    isDeviceConnected = NO;
    [self stopPairTimer];
    [self stopBatteryTimer];
    
    /* Send connection status as FLASE to KONY */
    NSMutableDictionary * connStatus = [NSMutableDictionary dictionary];
    [connStatus  setObject:[NSNumber numberWithInteger:0]  forKey:@"connStatus"];
    [connStatus  setObject:[NSNumber numberWithInteger:0]  forKey:@"isManualConn"];
    [KonyBridge sendDataToApp:connStatus callback:self.connectCallbackObj];
    
    /* Start the iOS accessories discovery which looking for paired reader when connected with iOS over bluetooth */
    [self startDeviceDiscovery];
    
    
}

/*
 Invoked when the reader returns an error while connecting.
 */

- (void)onError:(NSString *)message {
    NSLog(@"MEG Ingenico FFI : Reader onError");
    NSLog(@"MEG Ingenico FFI : An error occured %@", message);
    [self stopPairTimer];
    isDeviceConnected = NO;
    [self stopBatteryTimer];
    
    /* Send connection status as FLASE along with the connecion identity whether the failure is due to autoconnection or manual connection to KONY */
    NSMutableDictionary * connStatus = [NSMutableDictionary dictionary];
    [connStatus  setObject:[NSNumber numberWithInteger:0]  forKey:@"connStatus"];
    if(!isConnectionInBG)
        [connStatus  setObject:[NSNumber numberWithInteger:1]  forKey:@"isManualConn"];
    else if(isRepairingRequested)
        [connStatus  setObject:[NSNumber numberWithInteger:0]  forKey:@"isManualConn"];
    [KonyBridge sendDataToApp:connStatus callback:self.connectCallbackObj];
    
    /* Start the iOS accessories discovery which looking for paired reader when connected with iOS over bluetooth */
    [self startDeviceDiscovery];
    
}


- (void)onPlugged{
    NSLog(@"MEG Ingenico FFI : Reder plugged into Audio jack");
    [[DeviceManagementHelper sharedInstance] stopScan];
}

/*
 Handler function when the paired ingenico reader found connected with iPad by accessory scan discovery
 @param device : Ingneico reader object which is found connected
 @param deviceType : reader's type which is found connected
 */
- (void)connectPairedDevice:(RUADevice*)device deviceType:(RUADeviceType)deviceType
{
    NSLog(@"MEG Ingenico FFI : IN connectPairedDevice");
    if(!pairedDeviceScanned ) {
        pairedDeviceScanned = YES;
        [SVProgressHUD dismiss];
        selectedRUADevice = device;
        isPairedDeviceFound = TRUE;
        /* Send pair status as TRUE to KONY */
       
        NSMutableDictionary * pairStatus = [NSMutableDictionary dictionary];
        [pairStatus setObject:[NSNumber numberWithInt:1]  forKey:@"pairStatus"];
        [KonyBridge sendDataToApp:pairStatus callback:self.pairCallbackObj];
        
        /* Establish the connection with the reader from APP */
        [self connectToDevice:device deviceType:selectedDeviceType];
            
    }
    
}

/* Establish the connection with the reader from APP
 @param device : Ingneico reader object
 @param deviceType : reader's type
 */
-(void) connectToDevice:(RUADevice*)device deviceType:(RUADeviceType)deviceType
{
    NSLog(@"MEG Ingenico FFI : connectToDevice");
    

    [[Ingenico sharedInstance].PaymentDevice setDeviceType:deviceType];
    [[Ingenico sharedInstance].PaymentDevice select:device];
    [[Ingenico sharedInstance].PaymentDevice initialize:self];
   
}

/*-(void) noPairedDevice
{
    NSLog(@"No Paired Devices callback");
    if(!isPaired){
        isPairedDeviceFound = FALSE;
        [[DeviceManagementHelper sharedInstance] stopScan];
        [SVProgressHUD dismiss];
        if(!isDeviceConnected){
            
            NSMutableDictionary * pairStatus = [NSMutableDictionary dictionary];
            [pairStatus setObject:[NSNumber numberWithInt:0]  forKey:@"pairStatus"];
            [KonyBridge sendDataToApp:pairStatus callback:self.pairCallbackObj];
            
            readyForPair = TRUE;
            
//            [self ShowErrMessage:@"" title:LSSTRING(@"strIngenicoMSGNoPair")];
            [self showAlertWithTitle:LSSTRING(@"strIngenicoMSGNoPair") andMessage:@""];

        }
        
    }
}
*/
/*
 Handler when iPad blutooth turned OFF
 */
-(void) noBTConnection:(BOOL)isDeviceOFF
{
    NSLog(@"MEG Ingenico FFI : No BT connection wiht iPad or Device");
    if(isDeviceOFF && !isiOSBTOFF){
        [self showAlertWithTitle:LSSTRING(@"striPadBluetoothoff") andMessage:@""];
        isiOSBTOFF = YES;
    }
    
    [[DeviceManagementHelper sharedInstance] stopScan];
    [SVProgressHUD dismiss];
}

#pragma mark - RUAAudioJackPairingListener

- (void)onPairConfirmation:(NSString *)readerPasskey mobileKey:(NSString *) mobilePasskey;
{
    NSLog(@"MEG Ingenico FFI : onPairConfirmation");
    NSLog(@"MEG Ingenico FFI : onPairConfirmation readerPasskey = %@",readerPasskey);
    NSLog(@"MEG Ingenico FFI : onPairConfirmation mobilePasskey = %@",mobilePasskey);
    dispatch_async(dispatch_get_main_queue(), ^{
        passkey =  [NSString stringWithFormat:@"%@", readerPasskey];
    });
}

/**
 * Called to indicate that the pairing process has successfully completed.
 */
- (void)onPairSucceeded
{
    
    
}
/**
 * Called to indicate that the pairing process has successfully completed.
 */
- (void)onPairSucceeded:(RUADevice*)device
{
    
    NSLog(@"MEG Ingenico FFI : onPairSucceeded = %@ - %@",[device name],[device identifier]);
    isRepairingRequested = FALSE;
    if(passkey){
        selectedRUADevice = device;
        dispatch_async(dispatch_get_main_queue(), ^{
            [[Ingenico sharedInstance].PaymentDevice releaseDevice:self];
        });
    }else{ // Device already found paired.
        //TO DO:
    }
    
    
    
}

/**
 * Store the reader info. from local DB to iPad keychain
 */
-(void) saveDeviceDetailTOKeychain:(NSString*) deviceName deviceIdentifier:(NSString*) deviceIdentifier
{
    NSLog(@"MEG Ingenico FFI : saveDeviceDetailTOKeychan = %@",deviceName);
    selectedRUADevice = [[RUADevice alloc] initWithName:deviceName withIdentifier:deviceIdentifier withCommunicationInterface:0];
    NSLog(@"MEG Ingenico FFI : saveDeviceDetailTOKeychan selectedRUADevice= %@",selectedRUADevice.name);
    [[DeviceManagementHelper sharedInstance] saveDevice:selectedRUADevice];
}

/**
 * Save the reader info. into iPad keychain
 */
-(void) saveDeviceDetail:(RUADevice*)device
{
    NSLog(@"MEG Ingenico FFI : saveDeviceDetail");
    selectedRUADevice = [[RUADevice alloc] initWithName:device.name withIdentifier:device.identifier withCommunicationInterface:0];
    [[DeviceManagementHelper sharedInstance] saveDevice:device];
    
}

/**
 * Invoked when a device manager releases all the resources it acquired.
 * */
-(void) done
{
    NSLog(@"MEG Ingenico FFI : done - device connection reset succesfully");
    
    dispatch_async(dispatch_get_main_queue(), ^{
        if(isRepairingRequested){
            [[Ingenico sharedInstance].PaymentDevice setDeviceType:RUADeviceTypeRP450c];
            [[Ingenico sharedInstance].PaymentDevice initialize:self];
            [[Ingenico sharedInstance] setLogging:YES];
        }else {
            [self saveDeviceDetail:selectedRUADevice];
            
            /* Send Pairing status as TRUE to KONY along with reader info. */
            NSMutableDictionary * pairStatus = [NSMutableDictionary dictionary];
            [pairStatus setObject:[NSNumber numberWithInt:1]  forKey:@"pairStatus"];
            NSMutableDictionary * deviceInfo = [NSMutableDictionary dictionary];
            [deviceInfo setObject:[NSString stringWithFormat:@"%@",selectedRUADevice.name]  forKey:@"name"];
            [deviceInfo setObject:[NSString stringWithFormat:@"%@",selectedRUADevice.identifier]  forKey:@"identifier"];
            [pairStatus setObject:deviceInfo  forKey:@"deviceInfo"];
            [KonyBridge sendDataToApp:pairStatus callback:self.pairCallbackObj];
            
            [self showAlertWithTitle:[NSString stringWithFormat:@"%@ %@. %@",LSSTRING(@"strIngenicoMSGPairSuccess"),passkey,LSSTRING(@"strIngenicoMSGPairSuccess1")] andMessage:@""];
        }
    });
}

/**
 * Called to indicate that the device manager does not support audio jack pairing.
 */
- (void) onPairNotSupported
{
    passkey = nil;
}

/**
 * Called to indicate that the pairing process failed.
 */
- (void) onPairFailed
{
    passkey = nil;
    NSLog(@"MEG Ingenico FFI : Pairing Failed");
    //    [self showAlertWithTitle:@"Pairing failed. Try again" andMessage:@""];
}



/*
 Swipe and process the payment
 
 @param amount : Total transaction amount
 @param merchantReferenceCode : Mercchant's code
 @param enrollToken : New enrollment
 @param tokenReferenceNo : token reference number
 @param memberData : billing info.
 @param paymentCallback : payment handler for kony
 */
-(void) swipeCardAndProcessPayment:(NSInteger *)amount merchantReferenceCode:(NSString *)merchantReferenceCode enrollToken:(BOOL)enrollToken tokenReferenceNo:(NSString *)tokenReferenceNo memberData:(NSDictionary *)memberData paymentCallback:(CallBack*)paymentCallback
{
    self.paymentCallbackObj = paymentCallback;
    NSLog(@"MEG Ingenico FFI : swipeCardAndProcessPayment = %zd",amount);
    [self stopBatteryTimer];
    [SVProgressHUD showWithStatus:LSSTRING(@"strMSGProcessingTransaction") maskType:SVProgressHUDMaskTypeGradient];
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if(isDeviceConnected) {
            if(!isLoggedIn) {
                [self loginAndProcess:amount merchantReferenceCode:merchantReferenceCode enrollToken:enrollToken tokenReferenceNo:tokenReferenceNo memberData:memberData transactionID:nil];
            }else {
                [self processTransaction:amount merchantReferenceCode:merchantReferenceCode enrollToken:enrollToken tokenReferenceNo:tokenReferenceNo memberData:memberData];
            }
        }else{
            [self showAlertWithTitle:LSSTRING(@"strIngenicoMSGDevNotConnected") andMessage:@""];
        }
    });
}

/*
 Swipe and process the payment
 
 @param transactionId : Transaction ID
 @param merchantReferenceCode : Mercchant's code
 @param voidCallback : void  handler for kony
 */
-(void) voidPayment:(NSString *)transactionId merchantReferenceCode:(NSString *)merchantReferenceCode voidCallback:(CallBack*)voidCallback
{
    NSLog(@"MEG Ingenico FFI : IN voidPayment transactionId= %@ , merchantReferenceCode = %@",transactionId,merchantReferenceCode);
    self.voidCallbackObj = voidCallback;
    [SVProgressHUD showWithStatus:LSSTRING(@"strMSGProcessingTransaction") maskType:SVProgressHUDMaskTypeGradient];
    if(!isLoggedIn) {
        [self loginAndProcess:-1  merchantReferenceCode:merchantReferenceCode enrollToken:FALSE tokenReferenceNo:nil memberData:nil transactionID:transactionId];
    }else {
        [self processVoid:transactionId merchantReferenceCode:merchantReferenceCode];
    }
    
}

-(void) processVoid:(NSString *)transactionId merchantReferenceCode:(NSString *)merchantReferenceCode
{
    
    NSLog(@"MEG Ingenico FFI : VOID REQUEST PARAM OriginalSaleTransactionID= %@, andCustomReference= %@",transactionId,merchantReferenceCode);
    
    IMSVoidTransactionRequest *voidRequest = [[IMSVoidTransactionRequest alloc] initWithOriginalSaleTransactionID:transactionId andClerkID:@"0" andLongitude:nil andLatitude:nil andCustomReference:(NSString *)merchantReferenceCode];
    
    [[Ingenico sharedInstance].Payment processVoidTransaction:voidRequest  andOnDone:^(IMSTransactionResponse *response, NSError *error)
     {
         [SVProgressHUD dismiss];
         
         [self setTransactionDetail:response error:error isTransVoid:TRUE];
         
     }];
}

/*
 -(void) processTransaction:(NSInteger)totalAmount
 {
 [[self topMostController].view endEditing:YES];
 IMSAmount *amount = [[IMSAmount alloc] initWithTotal:totalAmount andSubtotal:0  andTax:0 andDiscount:0 andDiscountDescription:@"RoamDiscount"  andTip:0 andCurrency:@"USD"];
 NSLog(@"amount = %ld",(long)[amount total]);
 //NSArray *products = [self getSampleProducts:amount];
 id TransactionRequest = [[IMSCreditSaleTransactionRequest alloc] initWithAmount:amount
 andProducts:nil
 andClerkID:0
 andLongitude:nil
 andLatitude:nil
 andTransactionGroupID:nil];
 
 
 NSLog(@"Tranx request  = %@",TransactionRequest);
 
 if(TransactionRequest != nil){
 
 [[Ingenico sharedInstance].Payment processCreditSaleTransactionWithCardReader:TransactionRequest
 andUpdateProgress:progressCallback
 andSelectApplication:applicationSelectionCallback
 andOnDone:doneCallback];
 
 }else {
 NSLog(@"Transcation request nil");
 }
 
 }
 */

/*
 Remove reader info from keychain
 */
- (void)resetPairing
{
    NSLog(@"MEG Ingenico FFI : resetPairing");
    [[DeviceManagementHelper sharedInstance] resetPairing];
    [self showAlertWithTitle:@"Ingenico pairing removed successfully from App." andMessage:@""];
}

/*
 Process the transaction by sdk
 */
-(void) processTransaction:(NSInteger)totalAmount merchantReferenceCode:(NSString *)merchantReferenceCode enrollToken:(BOOL)enrollToken tokenReferenceNo:(NSString *)tokenReferenceNo memberData:(NSDictionary *)memberData
{
    
    NSLog(@"MEG Ingenico FFI :  IN processTransaction totalAmount = %ld, merchantReferenceCode = %@, enrollToken = %d, tokenReferenceNo = %@, memberData = %@",(long)totalAmount,merchantReferenceCode,enrollToken, tokenReferenceNo, [memberData description]);
    
    
    NSLog(@"MEG Ingenico FFI : SALE REQUEST PARAM amount= %ld",(long)totalAmount);
    NSLog(@"MEG Ingenico FFI : SALE REQUEST PARAM andCustomReference= %@",merchantReferenceCode);
    NSLog(@"MEG Ingenico FFI : SALE REQUEST PARAM enrollToken= %d",enrollToken);
    NSLog(@"MEG Ingenico FFI : SALE REQUEST PARAM tokenReferenceNo= %@",tokenReferenceNo);
    NSLog(@"MEG Ingenico FFI : SALE REQUEST PARAM token parameter= %@", [memberData description]);
    
    IMSAmount *amount = [[IMSAmount alloc] initWithTotal:totalAmount andSubtotal:0  andTax:0 andDiscount:0 andDiscountDescription:@"RoamDiscount"  andTip:0 andCurrency:@"USD"];
    
    IMSTokenRequestParametersBuilder *builder = [[IMSTokenRequestParametersBuilder alloc] init];
    
    builder.tokenReferenceNumber = tokenReferenceNo;
    builder.tokenFeeInCents = 0;
    if(memberData) {
        builder.cardholderLastName = [memberData objectForKey:@"lastName"];
        builder.cardholderFirstName = [memberData objectForKey:@"firstName"];
        builder.billToEmail = [memberData objectForKey:@"email"];
        builder.billToAddress1 = [memberData objectForKey:@"billingAddr1"];
        builder.billToAddress2 = [memberData objectForKey:@"billingAddr2"];
        builder.billToCity = [memberData objectForKey:@"city"];
        builder.billToState = [memberData objectForKey:@"state"];
        builder.billToCountry = [memberData objectForKey:@"country"];
        builder.billToZip = [memberData objectForKey:@"zip"];
    }
    IMSTokenRequestParameters *tokenRequest = nil;
    if(enrollToken)
        tokenRequest =  builder.createTokenEnrollmentRequestParameters;
    
    
    id TransactionRequest = [[IMSCreditSaleTransactionRequest alloc] initWithAmount:amount
                                                                        andProducts:nil
                                                                         andClerkID:nil
                                                                       andLongitude:nil
                                                                        andLatitude:nil
                                                              andTransactionGroupID:nil
                                                                andTransactionNotes:nil
                                                               andMerchantInvoiceID:nil
                                                    andShowNotesAndInvoiceOnReceipt:false
                                                          andTokenRequestParameters:tokenRequest
                                                                 andCustomReference:merchantReferenceCode];
    
    if(TransactionRequest != nil){
        
        [[Ingenico sharedInstance].Payment processCreditSaleTransactionWithCardReader:TransactionRequest
                                                                    andUpdateProgress:progressCallback
                                                                 andSelectApplication:applicationSelectionCallback
                                                                            andOnDone:doneCallback];
        
    }else {
        NSLog(@"MEG Ingenico FFI : Transcation request nil");
    }
    
}


-(void) processTransactionToken:(NSInteger)totalAmount
{
    NSLog(@"MEG Ingenico FFI : IN processTransactionToken TEST METHODs");
    
    
    IMSAmount *amount = [[IMSAmount alloc] initWithTotal:totalAmount andSubtotal:0  andTax:0 andDiscount:0 andDiscountDescription:@"RoamDiscount"  andTip:0 andCurrency:@"USD"];
    
    IMSTokenRequestParametersBuilder *builder = [[IMSTokenRequestParametersBuilder alloc] init];
    
    builder.tokenReferenceNumber = @"101693";
    builder.tokenFeeInCents = 0;
    builder.cardholderLastName = @"Data";
    builder.cardholderFirstName = @"Roam";
    builder.billToEmail = @"roam@roamdata.com";
    builder.billToAddress1 = @"1 Federal St";
    builder.billToAddress2 = @"Suite 1";
    builder.billToCity = @"Boston";
    builder.billToState = @"MA";
    builder.billToCountry = @"USA";
    builder.billToZip = @"02110";
    
    IMSTokenRequestParameters *tokenRequest =  builder.createTokenEnrollmentRequestParameters;
    
    
    id TransactionRequest = [[IMSCreditSaleTransactionRequest alloc] initWithAmount:amount
                                                                        andProducts:nil
                                                                         andClerkID:nil
                                                                       andLongitude:nil
                                                                        andLatitude:nil
                                                              andTransactionGroupID:nil
                                                                andTransactionNotes:nil
                                                               andMerchantInvoiceID:nil
                                                    andShowNotesAndInvoiceOnReceipt:false
                                                          andTokenRequestParameters:tokenRequest
                                                                 andCustomReference:@"101693-234567"];
    
    if(TransactionRequest != nil){
        
        [[Ingenico sharedInstance].Payment processCreditSaleTransactionWithCardReader:TransactionRequest
                                                                    andUpdateProgress:progressCallback
                                                                 andSelectApplication:applicationSelectionCallback
                                                                            andOnDone:doneCallback];
        
    }else {
        NSLog(@"Transcation request nil");
    }
    
    
}


/*
 Callbacks Invoked when the transaction process is complete/has been a progress
 */
- (void) setUpCallTransactionCallback
{
    currentVC = self;
    doneCallback = ^void(IMSTransactionResponse *response, NSError *error){
        
        
        NSLog(@"MEG Ingenico FFI : Tranx response  = %@",[IMSTransactionResponse class]);
        
        [SVProgressHUD dismiss];
        
        [currentVC startBatteryTimer];
        
        [currentVC setTransactionDetail:response error:error isTransVoid:FALSE];
    };
    
    progressCallback = ^void(IMSProgressMessage message, NSString *extraMessage){
        
        NSString *strMessage = [currentVC getProgressStrFromMessage:message];
        NSLog(@"progressCallback: %@",strMessage);
        if(strMessage){
            [SVProgressHUD showWithStatus:strMessage maskType:SVProgressHUDMaskTypeGradient];
        }
    };
    
    applicationSelectionCallback = ^void(NSArray *applicationList, NSError *error, ApplicationSelectedResponse reponse){
        [SVProgressHUD dismiss];
        
        NSLog(@"MEG Ingenico FFI : applicationSelectionCallback:");
        UIAlertController *view = [UIAlertController
                                   alertControllerWithTitle:@"Select application for your card"
                                   message:@"Make your choice"
                                   preferredStyle:UIAlertControllerStyleActionSheet];
        for (RUAApplicationIdentifier *appID in applicationList) {
            UIAlertAction *ok = [UIAlertAction
                                 actionWithTitle:appID.applicationLabel
                                 style:UIAlertActionStyleDefault
                                 handler:^(UIAlertAction *action) {
                                     [SVProgressHUD showWithStatus:@"Processing card transaction" maskType:SVProgressHUDMaskTypeGradient];
                                     [view dismissViewControllerAnimated:YES completion:nil];
                                     reponse(appID);
                                 }];
            [view addAction:ok];
        }
        UIAlertAction *cancel = [UIAlertAction
                                 actionWithTitle:@"Cancel"
                                 style:UIAlertActionStyleCancel
                                 handler:^(UIAlertAction *action) {
                                     reponse(nil);
                                 }];
        [view addAction:cancel];
    };
}

/*
 Parse the transaction response after payment proccesed.
 */

-(void) setTransactionDetail:(IMSTransactionResponse *) response error:(NSError *)error isTransVoid:(BOOL)isTransVoid
{
    NSMutableDictionary * transData = [NSMutableDictionary dictionary];
    [transData setObject:([NSNumber numberWithInteger:error.code] != nil) ? [NSNumber numberWithInteger:error.code] : @"" forKey:@"ResponseCode"];
    [transData setObject:([self getResponseCodeString:error.code]!= nil) ? [self getResponseCodeString:error.code]  : @"" forKey:@"ResponseMsg"];
    [transData setObject:(response.transactionID!= nil) ? response.transactionID : @"" forKey:@"RequestId"];
    [transData setObject:(response.clerkDisplay!= nil) ? response.clerkDisplay : @"" forKey:@"ClerkDisplay"];
    [transData setObject:([self getStrFromPOSEntryMode:response.posEntryMode]!= nil) ?[self getStrFromPOSEntryMode:response.posEntryMode] : @""  forKey:@"POSMode"];
    [transData setObject:[NSNumber numberWithInteger:response.authorizedAmount]  forKey:@"Amount"];
    [transData setObject:(response.invoiceID!= nil) ? response.invoiceID : @""  forKey:@"InvoiceNumber"];
    [transData setObject:(response.authCode!= nil) ? response.authCode : @""  forKey:@"AuthorizationCode"];
    [transData setObject:(response.clientTransactionID!= nil) ? response.clientTransactionID : @""  forKey:@"ReferenceNumber"];
    [transData setObject:(response.sequenceNumber!= nil) ? response.sequenceNumber : @""  forKey:@"SequenceNumber"];
    
    [transData setObject:(response.cardExpirationDate!= nil) ? response.cardExpirationDate : @""  forKey:@"ExpirationDate"];
    
    if(response.tokenResponseParameters.responseCode != IMSTokenResponseCodeUnknown) {
        NSLog(@"MEG Ingenico FFI : tokenResponseParameters responseCode: %lu", (unsigned long)response.tokenResponseParameters.responseCode);
        
        NSLog(@"MEG Ingenico FFI : tokenResponseParameters tokenIdentifier: %@", response.tokenResponseParameters.tokenIdentifier);
        
        NSLog(@"MEG Ingenico FFI : tokenResponseParameters tokenSource = %@",response.tokenResponseParameters.tokenIdentifier);
        
        NSLog(@"MEG Ingenico FFI : tokenResponseParameters tokenSourceData = %@",response.tokenResponseParameters.tokenSourceData);
        
        NSLog(@"MEG Ingenico FFI : tokenResponseParameters = %@",[self dictionaryWithPropertiesOfObject:response.tokenResponseParameters]);
        
        [transData setObject:(response.tokenResponseParameters.tokenSource) ? response.tokenResponseParameters.tokenSource : @"" forKey:@"tokenSource"];
        [transData setObject:(response.tokenResponseParameters.tokenSourceData) ? response.tokenResponseParameters.tokenSourceData : @"" forKey:@"tokenSourceData"];
        [transData setObject:(response.tokenResponseParameters.tokenIdentifier) ? response.tokenResponseParameters.tokenIdentifier : @""  forKey:@"tokenIdentifier"];
        
        if(response.tokenResponseParameters.responseCode == IMSTokenResponseCodeApproved)
        {
            
            [transData setObject:(response.tokenResponseParameters.tokenIdentifier!= nil) ? response.tokenResponseParameters.tokenIdentifier : @""  forKey:@"Token"];
        }else {
            [transData setObject:@""  forKey:@"Token"];
        }
    }else {
        [transData setObject:@""  forKey:@"Token"];
    }
    NSLog(@"MEG Ingenico FFI : transData: %@", [transData description]);
    NSLog(@"MEG Ingenico FFI : response: %@", [response description]);
    
    if(error.code == InvalidSessionToken)
        [self setLoggedIn:FALSE];
    
    if(!isTransVoid)
    {
        if(error.code == Success)
        {
            [self getCardDetail:response.transactionID transactionData:transData];
        }else {
            [KonyBridge sendDataToApp:transData callback:self.paymentCallbackObj];
        }
    }else{
        [KonyBridge sendDataToApp:transData callback:self.voidCallbackObj];
    }
}


/*
 Get the card detail from  the transaction  after payment proccesed.
 */
-(void) getCardDetail:(NSString *)transactionReference transactionData:(NSMutableDictionary *) transData
{
    NSLog(@"MEG Ingenico FFI : IN getCardDetail");
    if(transactionReference!=nil) {
        [[Ingenico sharedInstance].User getTransactionDetailsWithTransactionID:transactionReference andOnDone:^(IMSTransactionHistoryDetail *transaction, NSError *error) {
            if(error){
                /*Get transaction detail failed(code in the response
                 will indicates the result)*/
                NSLog(@"MEG Ingenico FFI : Error in getTransactionDetailsWithTransactionID = %@",error);
                
            }
            else{
                NSLog(@"MEG Ingenico FFI : transaction history = %@",[self dictionaryWithPropertiesOfObject:transaction]);
                NSLog(@"MEG Ingenico FFI : transaction tokenResponse history = %@",[self dictionaryWithPropertiesOfObject:transaction.tokenResponse]);
                NSLog(@"MEG Ingenico FFI : cardHolderName = %@",transaction.cardHolderName);
                if(transaction) {
                    [transData setObject:(transaction.cardHolderName) ? transaction.cardHolderName : @"" forKey:@"cardHolderName"];
                    [transData setObject:(transaction.cardType) ? [NSNumber numberWithInt:transaction.cardType] : 0 forKey:@"cardType"];
                    [transData setObject:(transaction.redactedCardNumber) ? transaction.redactedCardNumber : @"" forKey:@"cardNumber"];
                }
                
            }
            [KonyBridge sendDataToApp:transData callback:currentVC.paymentCallbackObj];
        }];
    }else {
        [KonyBridge sendDataToApp:transData callback:currentVC.paymentCallbackObj];
    }
    //  return cardData;
}
//Add this utility method in your class.
- (NSDictionary *) dictionaryWithPropertiesOfObject:(id)obj
{
    NSMutableDictionary *dict = [NSMutableDictionary dictionary];
    
    unsigned count;
    objc_property_t *properties = class_copyPropertyList([obj class], &count);
    
    for (int i = 0; i < count; i++) {
        NSString *key = [NSString stringWithUTF8String:property_getName(properties[i])];
        Class classObject = NSClassFromString([key capitalizedString]);
        if (classObject) {
            id subObj = [self dictionaryWithPropertiesOfObject:[obj valueForKey:key]];
            [dict setObject:subObj forKey:key];
        }
        else
        {
            id value = [obj valueForKey:key];
            if(value) [dict setObject:value forKey:key];
        }
    }
    
    free(properties);
    
    return [NSDictionary dictionaryWithDictionary:dict];
}

- (void)showAlertWithTitle:(NSString *)title andMessage:(NSString *)message{
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"11.0")) {
        UIAlertController *controller = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [controller addAction:action];
        [[self topMostController] presentViewController:controller animated:YES completion:nil];
    }else{
        UIAlertView* alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
        [alert show];

    }
    
    
}


- (NSString *)getResponseCodeString:(IMSResponseCode)responseCode {
    switch (responseCode) {
        case Success:
            return @"Success";
        case PaymentDeviceNotAvailable:
            return LSSTRING(@"strPaymentDeviceNotAvailable");//@"Payment Device Not Available";
        case PaymentDeviceError:
            return LSSTRING(@"strPaymentDeviceNotError");//@"Payment Device Not Error";
        case PaymentDeviceTimeout:
            return LSSTRING(@"strIngenicoMSGSwipeAgain");//@"Payment Device Timeouts";
        case NotSupportedByPaymentDevice:
            return LSSTRING(@"strNotSupportedbyPaymentDevice");//@"Not Supported by Payment Device";
        case CardBlocked:
            return LSSTRING(@"strCardBlocked");//@"Card Blocked";
        case ApplicationBlocked:
            return LSSTRING(@"strApplicationBlocked");//@"Application Blocked";
        case InvalidCard:
            return LSSTRING(@"strInvalidCard");//@"Invalid Card";
        case InvalidApplication:
            return LSSTRING(@"strInvalidCardApplication");//@"Invalid Card Application";
        case TransactionCancelled:
            return LSSTRING(@"strTransactionCancelled");//@"Transaction Cancelled";
        case CardReaderGeneralError:
            return LSSTRING(@"strCardReaderGeneralError");//@"Card Reader General Error";
        case CardInterfaceGeneralError:
            return LSSTRING(@"strCardNotAccepted");//@"Card Not Accepted";
        case BatteryTooLowError:
            return LSSTRING(@"strBatteryTooLow");//@"Battery Too Low";
        case BadCardSwipe:
            return LSSTRING(@"strBadCardSwipe");//@"Bad Card Swipe";
        case TransactionDeclined:
            return LSSTRING(@"strTransactionDeclined");//@"Transaction Declined";
        case TransactionReversalCardRemovedFailed:
            return @"Transaction Reversal Card Removed Failed";
        case TransactionReversalCardRemovedSuccess:
            return @"Transaction Reversal Card Removed Success";
        case TransactionReversalChipDeclineFailed:
            return @"Transaction Reversal Chip Decline  Failed";
        case TransactionReversalChipDeclineSuccess:
            return @"Transaction Reversal Chip Decline Success";
        case TransactionRefusedBecauseOfTransactionWithPendingSignature:
            return @"Transaction Refused Because Of Transaction With Pending Signature";
        case UnsupportedCard:
            return LSSTRING(@"strUnsupportedCard");//@"Unsupported Card";
        case InvalidSessionToken:
            [self setLoggedIn:FALSE];
            return LSSTRING(@"strSessionInvalidate");
        case HostExpiredCard:
            return LSSTRING(@"strExpiredcard");
        case AccountLocked:
            return LSSTRING(@"strUserAccountislocked");
        default:
            return[[NSString alloc] initWithFormat:@"response Code:%lu",(unsigned long)responseCode];
    }
    
}
- (NSString *)getStrFromPOSEntryMode:(IMSPOSEntryMode)entryMode{
    switch (entryMode) {
        case POSEntryModeKeyed:
            return @"Keyed";
        case POSEntryModeContactEMV:
            return @"ContactEMV";
        case POSEntryModeContactlessEMV:
            return @"ContactlessEMV";
        case POSEntryModeContactlessMSR:
            return @"ContactlessMSR";
        case POSEntryModeMagStripe:
            return @"MagStripe";
        case POSEntryModeMagStripeEMVFail:
            return @"MagStripeEMVFail";
        case POSEntryModeVirtualTerminal:
            return @"VirtualTerminal";
        case POSEntryModeUnKnown:
        default:
            return @"Unknown";
    }
}

- (NSString *)getProgressStrFromMessage:(IMSProgressMessage)message{
    switch (message) {
        case PleaseInsertCard:
            return LSSTRING(@"strPleaseswipeCreditCard");// return @"Please insert card";
        case CardInserted:
            return @"Card inserted";
        case ICCErrorSwipeCard:
            return @"ICCError swipe card please";
        case ApplicationSelectionStarted:
            return @"Application selection started";
        case ApplicationSelectionCompleted:
            return @"Application selection completed";
        case FirstPinEntryPrompt:
            return @"First Pin prompt";
        case LastPinEntryPrompt:
            return @"Last Pin prompt";
        case PinEntryFailed:
            return @"Pin entry failed";
        case PinEntryInProgress:
            return @"Pin entry in progress";
        case PinEntrySuccessful:
            return @"Pin entry in progress";
        case RetrytPinEntryPrompt:
            return @"Retry Pin entry prompt";
        case WaitingforCardSwipe:
            return @"Waiting for card swipe";
        case PleaseSeePhone:
            return @"Please see phone";
        case SwipeDetected:
            return LSSTRING(@"strSwipedetected");//@"Swipe detected";
        case SwipeErrorReswipeMagStripe:
            return LSSTRING(@"strReswipeplease");//@"Reswipe please";
        case TapDetected:
            return @"Tap detected";
        case UseContactInterfaceInsteadOfContactless:
            return @"Use contact interface instead of contactless";
        case ErrorReadingContactlessCard:
            return @"Error reading contactless card";
        case DeviceBusy:
            return @"Device busy";
        case CardHolderPressedCancelKey:
            return @"Cancel key pressed";
        case RecordingTransaction:
            return @"Recording transaction";
        case UpdatingTransaction:
            return @"Updating transaction";
        case PleaseRemoveCard:
            return @"Please remove card";
        case RestartingContactlessInterface:
            return @"Restarting contactless interface";
        case GettingOnlineAuthorization:
            return @"Getting Online Authorization";
        case TryContactInterface:
            return @"Try contact interface";
        case MultipleContactlessCardsDetected:
            return @"Please present one card only";
        case PresentCardAgain:
            return @"Please present card again";
        case CardRemoved:
            return @"Card Removed";
        case Unknown:
        default:
            return nil;
    }
}
- (NSString *)getStrFromTokenResponseCode:(IMSTokenResponseCode)code{
    switch (code) {
        case IMSTokenResponseCodeApproved:
            return @"Approved";
        case IMSTokenResponseCodeDeclined:
            return @"Token not requested because the transaction authorization was declined";
        case IMSTokenResponseCodeError:
            return @"Service provider error. See TokenSourceData for details.";
        case IMSTokenResponseCodeCommunicationError:
            return @"Error connecting to the tokenization service provider.";
        default:
            return @"Unknown";
    }
}



@end
