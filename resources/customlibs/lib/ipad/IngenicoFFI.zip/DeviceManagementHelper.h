//  DeviceManagementHelper.h


#import <Foundation/Foundation.h>
#import <RUA_MFI/RUA.h>
#import "KeychainItemWrapper.h"

@protocol DeviceManagementDelegate <NSObject>

- (void)connectPairedDevice:(RUADevice*)device deviceType:(RUADeviceType)deviceType;
//- (void)noPairedDevice;
-(void) noBTConnection:(BOOL)isDeviceOFF;

@end

@interface DeviceManagementHelper : NSObject

@property(nonatomic, retain) RUADevice* pairedDevice;

+ (id)sharedInstance;

- (void)initiateScan;

- (void)stopScan;

- (void)saveDevice:(RUADevice*)device;
- (void)retrievePairedDevices;
- (void)resetPairing;
@end
