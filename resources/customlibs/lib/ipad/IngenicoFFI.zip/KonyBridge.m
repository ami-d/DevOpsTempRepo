//
//  IMSBaseViewController.m
//  IngenicoSDKTestApp

#import "KonyBridge.h"
#import "lglobals.h"

//static bool initDeviceDone;

static CallBack * pairCallbackObj;

@interface KonyBridge ()
{

}

@end

@implementation KonyBridge


+(void) sendDataToApp:(id)data callback:(CallBack *)pairCallbackObj
{
    NSArray *temp=[[NSArray alloc] initWithObjects:data, nil];
    dispatch_async(dispatch_get_main_queue(), ^{

        executeClosure(pairCallbackObj,temp , NO);
    });
}

- (id)init
{
    self = [super init];
    if (self)
    {
        NSLog(@"%p init",self);
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
    NSLog(@"%p dealloc",self);
}

@end
