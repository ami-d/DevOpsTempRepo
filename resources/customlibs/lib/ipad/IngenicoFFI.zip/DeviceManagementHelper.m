//  DeviceManagementHelper.h


#import "DeviceManagementHelper.h"
#import <ExternalAccessory/ExternalAccessory.h>
#import <CoreBluetooth/CoreBluetooth.h>



@interface DeviceManagementHelper() <CBCentralManagerDelegate>
{
    CBCentralManager *blueToothManager;
    EAAccessoryManager *accessoryManager;
    NSMutableArray *pairedDevices;
    NSMutableDictionary *pairedDeviceTypes;
    id<DeviceManagementDelegate> _delegate;
    BOOL isScanInitiated;
    KeychainItemWrapper *keychain;
}

@end

@implementation DeviceManagementHelper

+ (id)sharedInstance {
    static DeviceManagementHelper *_instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _instance = [[DeviceManagementHelper alloc] init];
    });
    return _instance;
}

- (id)init {
    if (self = [super init]) {
        pairedDevices = [NSMutableArray new];
        accessoryManager = [EAAccessoryManager sharedAccessoryManager];
        keychain = [[KeychainItemWrapper alloc] initWithIdentifier:@"IngenicoStore" accessGroup:nil];

    }
    return self;
}

- (void)setDelegate:(id<DeviceManagementDelegate>)delegate{
    _delegate = delegate;
}
/*
 Get the reader info from iPad Keychain
 */
- (void)retrievePairedDevices
{
    NSLog(@"MEG Ingenico FFI : IN retrievePairedDevices");
     _pairedDevice = nil;
    NSString *deviceName=[keychain objectForKey:(id)kSecAttrLabel];
    NSString *deviceIdentifier=[keychain objectForKey:(id)kSecAttrType];

    
    [pairedDevices removeAllObjects];

    NSLog(@"MEG Ingenico FFI : IN retrievePairedDevices deviceName= %@ - deviceIdentifier=%@",deviceName,deviceIdentifier);
    if(deviceName && deviceIdentifier && deviceName.length > 0 &&  deviceIdentifier.length > 0){
    RUADevice* device =[[RUADevice alloc] initWithName:deviceName withIdentifier:deviceIdentifier withCommunicationInterface:0];
    _pairedDevice = device;
    [pairedDevices addObject:device];
    }
}

/*
 Start the accessory scan
 */
- (void)initiateScan
{
    NSLog(@"MEG Ingenico FFI : IN initiateScan");
    isScanInitiated = YES;
    blueToothManager = [[CBCentralManager alloc] initWithDelegate:self queue:nil options:nil];
    
    [accessoryManager registerForLocalNotifications];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(accessoryDidConnect:)
                                                 name:EAAccessoryDidConnectNotification
                                               object:nil];
    //Scan for MFI devices (RP450)
    for(EAAccessory *accessory in accessoryManager.connectedAccessories)
    {
        if([accessory.name length]>0)
        {
            [self checkScannedPeripheralDeviceIsAlreadyPaired:accessory.name isBLE:NO  deviceConnectedStatus:YES];
             NSLog(@"MEG Ingenico FFI : Reader Alredy found conneted with iPad = %@",accessory.name);
        }
    }
}

/*
 Stop the accessory scan
 */
- (void)stopScan{
    NSLog(@"MEG Ingenico FFI : IN stopScan");
    isScanInitiated = NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        /* Do some heavy work (you are now on a background queue) */
        [accessoryManager unregisterForLocalNotifications];
        [[NSNotificationCenter defaultCenter] removeObserver:EAAccessoryDidConnectNotification];
        [blueToothManager stopScan];

        dispatch_sync(dispatch_get_main_queue(), ^{
            /* stop the activity indicator (you are now on the main queue again) */
        });
    });
    
}
/*
 Save the reader info from iPad Keychain
 */
- (void)saveDevice:(RUADevice*)device
{
    [keychain setObject:device.name forKey:(id)kSecAttrLabel];
    [keychain setObject:device.identifier forKey:(id)kSecAttrType];
    [self retrievePairedDevices];
}

/*
 Check the reader connected with iPad blutooth is the same as stored in keychain
 */
- (void)checkScannedPeripheralDeviceIsAlreadyPaired:(NSString*)deviceName isBLE:(BOOL)BLE deviceConnectedStatus:(BOOL)isConnected
{
    NSLog(@"MEG Ingenico FFI : IN checkScannedPeripheralDeviceIsAlreadyPaired");
    [self retrievePairedDevices];
     NSLog(@"MEG Ingenico FFI : Paired Device Name = %@",deviceName);
    if(pairedDevices.count > 0)
    {
        for(RUADevice *device in pairedDevices)
        {
            if([[device.name lowercaseString] isEqualToString:[deviceName lowercaseString]])
            {
                
                if(!BLE)
                {
                    [self stopScan];
                    [_delegate connectPairedDevice:device deviceType:RUADeviceTypeRP450c];
                }else {
                  //  [_delegate noPairedDevice]; //forgot the device from iPad - app still have data
                }
                break;
            }
        }
    }else{
        //[_delegate noPairedDevice];
    }
}

- (void)resetPairing
{
    [keychain resetKeychainItem];
}

#pragma mark - CBCentralManagerDelegate delegate Methods


- (void)centralManagerDidUpdateState:(CBCentralManager *)central
{
    if(blueToothManager.state == CBCentralManagerStatePoweredOn)
    {
        //Scan for BLE devices (RP750/MOBY3000)s
        [blueToothManager scanForPeripheralsWithServices:nil options:@{ CBCentralManagerScanOptionAllowDuplicatesKey : @NO }];
    }else {
            [_delegate noBTConnection:YES];
    }
}

- (void)centralManager:(CBCentralManager *)central didDiscoverPeripheral:(CBPeripheral *)peripheral advertisementData:(NSDictionary *)advertisementData RSSI:(NSNumber *)RSSI {
    
    if([peripheral.name length]>0)
    {
        // Connect only BLE devices using this delegate method. Activating MFI devices may fail when MFI devices are not connected in system's bluetooth settings. Use EAAccessoryDidConnectNotification method to connect MFI devices.
       // [self checkScannedPeripheralDeviceIsAlreadyPaired:peripheral.name isBLE:YES deviceConnectedStatus:peripheral.state == CBPeripheralStateConnected ? YES : NO];
       // NSLog(@"Paired Device Name 1 = %@",peripheral.name);
    }else {
        //[_delegate noBTConnection:YES];
    }
}

#pragma mark - EAAccessoryDidConnectNotification

- (void)accessoryDidConnect:(NSNotification*)note
{
    EAAccessory* accessory = [note.userInfo objectForKey:EAAccessoryKey];
    
    if([accessory.name length]>0)
    {
         NSLog(@"MEG Ingenico FFI : Paired reader got connected while scanning = %@",accessory.name);
        [self checkScannedPeripheralDeviceIsAlreadyPaired:accessory.name isBLE:NO deviceConnectedStatus:YES];
       
    }
}


-(void) dealloc
{
    
}

@end
