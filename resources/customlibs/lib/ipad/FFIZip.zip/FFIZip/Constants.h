//
//  Constants.h
//  YCMatrix
//
//  Created by Ioannis Chatzikonstantinou on 25/9/14.
//  Copyright (c) 2014 Ioannis Chatzikonstantinou. All rights reserved.
//

#ifndef YCMatrix_Constants_h
#define YCMatrix_Constants_h

#define ARC4RANDOM_MAX      0x100000000

#endif
