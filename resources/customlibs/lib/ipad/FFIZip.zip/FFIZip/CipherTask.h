//
//  CipherTask.h
//  TaskFrameworkLibrary
//
//  Created by MADP on 08/09/16.
//  Copyright © 2016 MADP. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "KSTask.h"
#import "KSTaskListener.h"

@interface CipherTask : KSTask <KSTaskListener>

@end
