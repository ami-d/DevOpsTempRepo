//
//  DownloadTask.h
//  TaskFrameworkLibrary
//
//  Created by MADP on 08/09/16.
//  Copyright © 2016 MADP. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "KSTask.h"
#import "KSTaskListener.h"
#import "BinaryDataManager.h"

@interface DownloadTask : KSTask <KSTaskListener>

@property (nonatomic, copy) startDownloadTaskCompletionBlock startDownloadTaskCompletionBlock;
@property (nonatomic, copy) pauseDownloadTaskCompletionBlock pauseDownloadTaskCompletionBlock;

-(void) pauseDownload;
-(void) resumeDownload;
@end
