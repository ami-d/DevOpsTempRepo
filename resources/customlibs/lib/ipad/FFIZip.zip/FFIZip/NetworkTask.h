//
//  NetworkTask.h
//  TaskFrameworkLibrary
//
//  Created by MADP on 08/09/16.
//  Copyright © 2016 MADP. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "KSTask.h"

@interface NetworkTask : KSTask

- (void)pauseDownload;
- (void)resumeDownload;

@end
