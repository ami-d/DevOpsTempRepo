//
//  BinaryDataManagerConstants.h
//  BinaryDataManager
//
//  Created by MADP on 27/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT int const kInsertProcessing;
FOUNDATION_EXPORT int const kInsertFailed;
FOUNDATION_EXPORT int const kUpdateProcessing;
FOUNDATION_EXPORT int const kUpdateFailed;
FOUNDATION_EXPORT int const kDeleteProcessing;
FOUNDATION_EXPORT int const kDeleteFailed;
FOUNDATION_EXPORT int const kFileDoesNotExist;
FOUNDATION_EXPORT int const kDownloadAccepted;
FOUNDATION_EXPORT int const kDownloadFailed;
FOUNDATION_EXPORT int const kDownloadFinished;
FOUNDATION_EXPORT int const kDownloadInProgress;
FOUNDATION_EXPORT int const kUploadAccepted;
FOUNDATION_EXPORT int const kUploadFailed;
FOUNDATION_EXPORT int const kUploadInProgress;
FOUNDATION_EXPORT int const kNoOperation;

@interface BinaryDataManagerConstants : NSObject

@end