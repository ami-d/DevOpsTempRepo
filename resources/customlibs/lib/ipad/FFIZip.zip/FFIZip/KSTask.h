//
//  KSTask.h
//  TaskFrameworkLibrary
//
//  Created by Sunil Phani Manne on 07/09/16.
//  Copyright © 2016 MADP. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Matrix;
@class KSTaskError;

typedef NS_ENUM(NSUInteger, KSTaskState) {
    KSTaskStateNotStarted = 0,
    KSTaskStateStarted,
    KSTaskStatePaused,
    KSTaskStateEnded,
    KSTaskStateErrored
};

@protocol KSTaskListener;

@interface KSTask : NSObject
{
@protected
    NSUInteger _taskBitMap;
    Matrix *_dependencyMatrix;
    NSMutableDictionary *_errorContext;
    NSMutableDictionary *_outputContext;
    NSMutableOrderedSet <KSTask *>* _subtasks;
}

//Identification properties
@property (nonatomic, readonly) NSString *ID;
@property (nonatomic, readonly) NSString *name;

//Subtask related properties
@property (nonatomic, readonly) NSOrderedSet <KSTask *>* subtasks;

//Input, Output & Error related properties
@property (nonatomic, copy) NSDictionary *inputContext;
@property (nonatomic, readonly) NSDictionary *outputContext;
@property (nonatomic, readonly) NSDictionary *errorContext;

//Miscellaneous properties
@property (nonatomic, readonly) KSTaskState state;

//init methods
- (instancetype)initWithName:(NSString *)name;
+ (instancetype)taskWithName:(NSString *)name;

//subtask related methods
- (void)addSubtask:(KSTask *)subtask;
- (void)removeSubtask:(KSTask *)subtask;
- (void)addSubtasks:(NSArray <KSTask *> *)subtasks;
- (void)removeSubtasks:(NSArray <KSTask *> *)subtasks;

//error flavoured methods
- (void)addSubtask:(KSTask *)subtask
             error:(NSError **)error;
- (void)removeSubtask:(KSTask *)subtask
                error:(NSError **)error;
- (void)addSubtasks:(NSArray <KSTask *> *)subtasks
              error:(NSError **)error;
- (void)removeSubtasks:(NSArray <KSTask *> *)subtasks
                 error:(NSError **)error;

//Exposed for ease
- (void)setState:(KSTaskState)state;
- (void)raiseError:(KSTaskError *)error;
- (void)raiseContextChangeEvent;
- (void)handleErrorsForTask:(KSTask *)task;

//Task control methods
- (void)start;
- (void)pause;
- (void)resume;
- (void)stop;
- (void)validateInput:(KSTaskError **)error;
- (void)execute;

//Dependency related methods
- (BOOL)checkForCyclicDependencyInMatrix;

- (void)addDependencyBetween:(KSTask *)task1
                    andTask2:(KSTask *)task2
                       error:(NSError **)error;

- (void)removeDependencyBetween:(KSTask *)task1
                       andTask2:(KSTask *)task2
                          error:(NSError **)error;

- (void)removeAllDependenciesWithError:(NSError **)error;

//(Un)subscription methods
- (BOOL)subscribeForTaskUpdates:(id <KSTaskListener>)listener;
- (BOOL)unsubscribeForTaskUpdates:(id <KSTaskListener>)listener;
- (BOOL)unsubscribeAll;

@end

