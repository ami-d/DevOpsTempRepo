//
//  SQLiteUtil.h
//  FMDBTest
//
//  Created by Krishna Nikhil Vedurumudi on 16/09/16.
//  Copyright © 2016 kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "FMDatabase.h"

@interface SQLiteUtil : NSObject

/*
 in table name.
 config will contains key value pairs..
 */


+ (BOOL) insertStatementForDatabase:(NSString *)dbPath ForTable:(NSString *)tableName withValues: (NSDictionary *)config;
+ (FMResultSet *) queryDataForDatabase:(NSString *)dbPath ForTable:(NSString *)tableName withWhereClause:(NSDictionary *)whereClause;
+ (BOOL) updateStatementForDatabase: (NSString *)dbName forTable: (NSString *)tableName withColumnsToBeUpdated: (NSDictionary *)columnNames withWhereClause: (NSDictionary *)whereClause;
+ (BOOL) deleteStatementForDatabase: (NSString *)dbName forTable: (NSString *)tableName withWhereClause: (NSDictionary *)whereClause
;

+ (BOOL) openDatabase: (FMDatabase *)db;
+ (BOOL) closeDatabase: (FMDatabase *)db;

+ (NSString *) createInsertSQLStatementForTable: (NSString *)tableName and: (NSDictionary *)values;
+ (NSString *) createFetchSQLStatementForTable: (NSString *)tableName withWhereClause: (NSDictionary *)whereClause;
+ (NSString *)createUpdateSQLStatementForTable: (NSString *)tableName forColumns: (NSDictionary *)columnNames withWhereClause: (NSDictionary *)whereClause;
+ (NSString *)createDeleteSQLStatementForTable: (NSString *)tableName withWhereClause: (NSDictionary *)whereClause;

@end
